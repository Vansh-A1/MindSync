# Reviewed MindSync knowledge corpus

Captured and checked **16 November 2026**. The corpus contains 40 passages from
38 selected sections, across seven official documents. It contains public source
text only; no user conversations, vitals, credentials, logos or illustrations.

| Source | Selection | Passages |
| --- | --- | ---: |
| [WHO: Doing what matters in times of stress](https://www.who.int/publications/i/item/9789240003927) | Five complete summary tools; physical PDF pages 124–128, printed pages 122–126 | 5 |
| [NHS: Self-help CBT techniques](https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/) | What is CBT? | 1 |
| [NHS: Reframing unhelpful thoughts](https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/reframing-unhelpful-thoughts/) | Cycle, technique overview and six steps | 8 |
| [NHS: Tackling your worries](https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/tackling-your-worries/) | Seven steps | 7 |
| [NHS: Problem solving](https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/problem-solving/) | Eight steps | 8 |
| [NHS: Staying on top of things](https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/staying-on-top-of-things/) | Six steps | 6 |
| [NIMH: Caring for Your Mental Health](https://www.nimh.nih.gov/health/topics/caring-for-your-mental-health) | Overview, self-care, when to seek professional help | 5 |

The WHO Stress Q&A entry is recorded as **excluded**, with no indexed text. Access
succeeded, but a page-specific open reuse licence was not established; the guide's
licence was not assumed to cover every WHO web page. No passage was invented or
misattributed to this excluded source.

## Attribution and reuse

**WHO excerpts:** Doing what matters in times of stress: an illustrated guide.
Geneva: World Health Organization; 2020. Licence:
[CC BY-NC-SA 3.0 IGO](https://creativecommons.org/licenses/by-nc-sa/3.0/igo/).
The guide-specific notice was checked on physical PDF page 4. The WHO-derived
text, including its normalized/selected representation in these files and any
evaluation previews, is distributed under that licence. Noncommercial reuse,
attribution and ShareAlike conditions apply; commercial reuse requires separate
permission. No endorsement by WHO is implied. The guide's illustrations are not
included. See the [WHO publication policy](https://www.who.int/about/policies/publishing/copyright).

**NHS excerpts:** [Information from the NHS website](https://www.nhs.uk/), as at
16 November 2026. Contains public sector information licensed under the
[Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/),
subject to [NHS terms and exclusions](https://www.nhs.uk/our-policies/terms-and-conditions/).
Text is selected and whitespace normalized; paragraph wording is preserved.
Display attribution, source links and the capture date when showing these excerpts.
Do not imply NHS approval of MindSync, clinical validation or endorsement. The
source terms distinguish unchanged and adapted content; respect those conditions
when refreshing, adapting or displaying material. Images/logos/third-party assets
are outside this text collection.

**NIMH excerpts:** National Institute of Mental Health, “Caring for Your Mental
Health,” captured 16 November 2026. Website text is public domain unless otherwise
specified; attribution is requested. This collection includes text only and implies
no NIMH endorsement. See [NIMH reuse policy](https://www.nimh.nih.gov/site-info/policies).

These notices describe the source material, not a licence grant for unrelated
project code. Keep the source notices with any redistributed corpus or previews.

## Provenance and reproducibility

- `sources.json`: canonical URLs, approved download URLs, publisher/title, selected
  sections, verification state/date, original document SHA-256 and licence notes.
- `verified_sections.jsonl`: selected blocks with document hash and physical PDF
  page where applicable. Each normalized block was checked as an exact substring
  of the downloaded official HTML or the selected PDF page's text.
- `verification.json`: section hashes and the check method. It is a provenance
  receipt, not proof of clinical accuracy or a cryptographic source signature.
- `passages.jsonl`: deterministic chunking output, including stable IDs and text hashes.

Raw files live only under ignored `runtime/source-audit/` in the development
checkout. The source URLs allow re-verification; websites may change, so future
downloads need review before replacing the committed corpus. Rebuilding from the
committed reviewed sections requires no source network access.

For WHO summaries, repeated headings, page numbers, audio-link callouts and two
diagram labels were omitted. All substantive summary instructions remain intact.
NHS promotional cards, navigation, videos and unrelated sections were excluded.
NIMH media/footer and regional crisis-link sections were not selected; crisis
routing belongs to the separate platform pathway, not this small general corpus.

Refer to the [RAG usage guide](../../src/mindsync/rag/README.md) for build, search,
refresh, evaluation and test commands. A reviewer must check new manual sources
against the original document before marking them verified; hashes alone cannot
make supplied text trustworthy.
