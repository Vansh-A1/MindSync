# Free hosted competition demo

Target: Streamlit Community Cloud, Python 3.11, entrypoint `deployment/streamlit_app.py`.
Use repository `Vansh-A1/MindSync`, branch `codex/cloud-demo`.
The nearest `deployment/requirements.txt` selects the tested CPU torch wheel and application dependencies.

In Advanced settings → Secrets, configure:

```toml
MINDSYNC_DEMO_PASSWORD = "choose-a-private-demo-access-code"
LLM_API_KEY = "enter-your-Groq-key-here"
```

Do not commit either value. The model is `openai/gpt-oss-20b`, with the guided workflow.
Without LLM_API_KEY the application labels its local deterministic mode; live output is never simulated.
The presenter code is required before starting or using any application services.

FastAPI stays on loopback inside the host; only Streamlit is exposed. The unchanged frozen hybrid index
is bundled under `deployment/assets/rag_index`. First boot downloads the exact pinned MiniLM model.
The synthetic database is seeded locally on the host. Lab records and check-in notes are not uploaded.
The existing RAG, API, contracts, agent, simulator, and dashboard source are reused unchanged.
Hosted check-ins are shared demo records; use fictional information only. Disk and chats are ephemeral.
Free hosting may sleep or impose resource limits. Rehearse and keep the app warm before presenting.

Select Live Groq explicitly in the sidebar, Student A, and simulated-vitals consent. In Comparison Lab use:
`I'm stressed about exams and sleeping poorly. Could we look at recent patterns?`
Check selected sources, traces, equal retrieval fingerprints, and A/B/C permissions.
A configured key alone does not prove live provider access.

The source release is `fb76335` / application `2bc97b0`. Hosting changes are additive and do not alter
the laptop ZIP or original working lab runtime. Never publish `.streamlit/secrets.toml` or `runtime/`.
