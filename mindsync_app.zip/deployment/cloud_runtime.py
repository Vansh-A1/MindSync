"""Run the unchanged MindSync API and simulator behind a hosted Streamlit UI."""
from __future__ import annotations
import atexit
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import httpx

ROOT = Path(__file__).resolve().parents[1]


def child_environment(home: Path, settings: dict, api_port: int = 8000) -> dict:
    env = dict(os.environ)
    # Carry only the explicitly selected hosted configuration into the service.
    for key in list(env):
        if key.startswith('RAG_') or key in {'LLM_API_KEY', 'GROQ_API_KEY'}:
            env.pop(key)
    env.update({
        'PYTHONPATH': str(ROOT/'src'), 'MINDSYNC_HOME': str(home),
        'MINDSYNC_DB_PATH': str(home/'runtime/mindsync.db'),
        'MINDSYNC_API_URL': f'http://127.0.0.1:{api_port}',
        'MINDSYNC_AGENT': 'live' if settings.get('LLM_API_KEY') else 'local',
        'AGENT_WORKFLOW': 'guided', 'MOCK_LLM': 'false',
        'LLM_MODEL': 'openai/gpt-oss-20b',
        'LLM_BASE_URL': 'https://api.groq.com/openai/v1',
        'MINDSYNC_SEED_DEMO': 'true', 'MINDSYNC_STALE_MINUTES': '120',
        'MINDSYNC_REQUEST_TIMEOUT': '45', 'HF_HUB_DISABLE_TELEMETRY': '1',
        'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1', 'LANGSMITH_TRACING': 'false',
        'TOKENIZERS_PARALLELISM': 'false', 'OMP_NUM_THREADS': '1',
        'MKL_NUM_THREADS': '1',
    })
    if settings.get('LLM_API_KEY'):
        env['LLM_API_KEY'] = settings['LLM_API_KEY']
    return env


class CloudRuntime:
    def __init__(self, home: Path, settings: dict, api_port: int = 8000):
        self.home = home
        self.url = f'http://127.0.0.1:{api_port}'
        self.children = []
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', api_port))
            sock.listen(1)
        env = child_environment(home, settings, api_port)
        home.mkdir(parents=True, exist_ok=True)
        index = home/'runtime/rag_index'
        if not index.exists():
            shutil.copytree(ROOT/'deployment/assets/rag_index', index)
        # Preserve the frozen index and download only the pinned model on first boot.
        model = home/'runtime/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/1110a243fdf4706b3f48f1d95db1a4f5529b4d41/model.safetensors'
        setup_env = dict(env)
        setup_env.pop('LLM_API_KEY', None)
        setup_env['HF_HUB_OFFLINE'] = '1' if model.exists() else '0'
        setup_env['TRANSFORMERS_OFFLINE'] = setup_env['HF_HUB_OFFLINE']
        setup = [sys.executable, '-m', 'mindsync.cli', '--home', str(home), 'setup']
        if not model.exists():
            setup.append('--download-model')
        result = subprocess.run(setup, env=setup_env, cwd=ROOT, capture_output=True, timeout=600)
        if result.returncode:
            # Provider credentials are never interpolated into errors or logs.
            raise RuntimeError('Hosted resource setup failed. Verify model-download access, Python 3.11, and available memory.')
        env['HF_HUB_OFFLINE'] = '1'
        env['TRANSFORMERS_OFFLINE'] = '1'
        try:
            self.children.append(subprocess.Popen([
                sys.executable, '-m', 'uvicorn', 'mindsync.platform.api:app',
                '--host', '127.0.0.1', '--port', str(api_port), '--no-access-log',
            ], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                if self.children[0].poll() is not None:
                    raise RuntimeError('Hosted API exited during startup. Check free-host memory and port availability.')
                try:
                    health = httpx.get(self.url+'/health', timeout=2)
                    if health.is_success and health.json().get('rag_ready'):
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(.3)
            else:
                raise RuntimeError('Hosted API readiness timeout.')
            self.children.append(subprocess.Popen([
                sys.executable, '-m', 'mindsync.simulator.publisher', '--url', self.url,
            ], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except BaseException:
            self.stop()
            raise
        atexit.register(self.stop)

    def healthy(self):
        return bool(self.children) and all(p.poll() is None for p in self.children)

    def stop(self):
        for child in reversed(self.children):
            if child.poll() is None:
                child.terminate()
        for child in self.children:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
