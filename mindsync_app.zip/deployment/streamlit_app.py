"""Hosted entrypoint: presenter access gate, local API, unchanged dashboard."""
import hashlib
import hmac
import importlib.util
import os
from pathlib import Path
import sys
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'deployment'))
from cloud_runtime import CloudRuntime


def setting(name):
    value = os.environ.get(name, '')
    if value:
        return value
    try:
        return str(st.secrets.get(name, ''))
    except (FileNotFoundError, st.errors.StreamlitSecretNotFoundError):
        return ''


def main():
    st.set_page_config(page_title='MindSync AI', page_icon='🌿', layout='wide')
    password = setting('MINDSYNC_DEMO_PASSWORD')
    if not password:
        st.error('Presenter setup required: configure MINDSYNC_DEMO_PASSWORD in the hosting Secrets settings.')
        st.stop()
    password_version = hashlib.sha256(password.encode()).hexdigest()
    if st.session_state.get('demo_access') != password_version:
        st.title('MindSync AI')
        st.caption('Competition demonstration · fictional profiles and simulated measurements')
        with st.form('presenter_access'):
            supplied = st.text_input('Demo access code', type='password')
            submitted = st.form_submit_button('Open demonstration')
        if submitted:
            if hmac.compare_digest(supplied, password):
                st.session_state['demo_access'] = password_version
                st.rerun()
            st.error('Access code not recognized.')
        st.stop()

    @st.cache_resource(show_spinner='Starting the verified RAG and synthetic demo. First boot downloads the pinned embedding model…')
    def runtime():
        home = Path(os.environ.get('MINDSYNC_CLOUD_HOME', str(ROOT/'runtime/cloud-demo')))
        return CloudRuntime(home, {'LLM_API_KEY': setting('LLM_API_KEY')},
                            api_port=int(os.environ.get('MINDSYNC_CLOUD_API_PORT', '8000')))

    try:
        service = runtime()
        if not service.healthy():
            service.stop()
            runtime.clear()
            st.error('A demo service stopped. Reload to restart; no mock result was substituted.')
            st.stop()
    except Exception:
        st.error('Hosted startup failed. Check host memory, Python 3.11, dependency installation, and model download access, then reboot this app.')
        st.stop()
    os.environ['MINDSYNC_API_URL'] = service.url
    st.info('Shared competition demo: use fictional information only. Demo records can reset when the free host restarts.')
    if not setting('LLM_API_KEY'):
        st.warning('Live Groq is not configured. Local guidance runs real RAG and LangGraph with deterministic selection and no language model.')
    spec = importlib.util.spec_from_file_location('mindsync_hosted_dashboard', ROOT/'frontend/app.py')
    dashboard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dashboard)
    dashboard.main()


if __name__ == '__main__':
    main()
