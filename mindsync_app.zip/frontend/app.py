"""Local dashboard. Readings, responses, traces and metrics come from the API."""

import os
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
import altair as alt
import httpx
import pandas as pd
import streamlit as st

MODES = {
    "A · Text only": "text_only",
    "B · Current vitals": "current_vitals",
    "C · Full context": "full_context",
}
PAGES = [
    "Overview",
    "AI Companion",
    "Comparison Lab",
    "Health Context",
    "Evidence & Evaluation",
]
BACKENDS = {"local": "Local guidance", "live": "Live Groq", "mock": "Test mock"}
OUTCOMES = {
    "grounded_selection": "Verified excerpts selected",
    "no_evidence": "No supporting evidence found",
    "evidence_not_selected": "Evidence found; no excerpt selected",
    "urgent_support": "Human support pathway",
    "unscored_response": "Response not scored",
}


def api(method, path, **kwargs):
    base = os.getenv("MINDSYNC_API_URL", "http://127.0.0.1:8000").rstrip("/")
    try:
        response = httpx.request(
            method,
            base + path,
            timeout=(3 * st.session_state.get("request_timeout_seconds", 45) + 20)
            if path.startswith("/compare")
            else st.session_state.get("request_timeout_seconds", 45) + 10,
            **kwargs,
        )
        if response.is_error:
            try:
                detail = response.json().get("detail", "Request could not be completed")
            except ValueError:
                detail = "Request could not be completed"
            st.error(f"{detail}. You can retry or change the selected mode/backend.")
            return None
        data = response.json()
        if path.startswith("/chat"):
            data["runtime"] = {
                name: response.headers.get(f"X-MindSync-{name}", "unknown")
                for name in ("Backend", "Workflow", "Outcome")
            }
        return data
    except httpx.HTTPStatusError as exc:
        try:
            detail = exc.response.json().get("detail", "Request could not be completed")
        except ValueError:
            detail = "Request could not be completed"
        st.error(f"{detail}. You can retry or change the selected mode/backend.")
    except (httpx.HTTPError, ValueError):
        st.error(
            "Cannot reach the local API. Start the API server, then choose Refresh data."
        )
    return None


def number(value, digits=1):
    if value is None:
        return "Unavailable"
    return f"{value:.{digits}f}".rstrip("0").rstrip(".") if digits else str(value)


def timestamp(value):
    if not value:
        return "No timestamp"
    try:
        return (
            datetime.fromisoformat(value.replace("Z", "+00:00"))
            .astimezone()
            .strftime("%d %b, %H:%M %Z")
        )
    except ValueError:
        return value


def navigate(page):
    st.session_state["page"] = page


def source_list(sources):
    for i, source in enumerate(sources, 1):
        st.markdown(f"**[{i}] {source['publisher']} · {source['title']}**")
        st.caption(source.get("section", ""))
        if urlparse(source["url"]).scheme == "https":
            st.link_button("Read original source", source["url"])
        st.caption(f"Source {source['source_id']} · Passage {source['chunk_id']}")


def show_response(response, runtime=None):
    runtime = runtime or response.get("runtime", {})
    outcome = runtime.get("Outcome", "unscored_response")
    if response["safety_route"] == "urgent_support":
        st.warning("Human support pathway · no model or tools used")
    elif outcome not in OUTCOMES:
        st.warning(
            f"Response could not be completed: {outcome.replace('_', ' ')}. This is not a grounded answer."
        )
    else:
        st.caption(OUTCOMES[outcome])
    st.write(response["reply"])
    context = (
        "Simulated context accessed"
        if response["simulated_data_used"]
        else "No physiological context used"
    )
    st.caption(
        f"{response['latency_ms']:,} ms · {len(response['sources'])} selected sources · {context}"
    )
    if response["sources"]:
        with st.expander(f"Selected sources ({len(response['sources'])})"):
            source_list(response["sources"])
    with st.expander(f"Tool activity ({len(response['tool_trace'])})"):
        if not response["tool_trace"]:
            st.caption("No tool executions were recorded.")
        for event in response["tool_trace"]:
            st.markdown(f"**{event['name']}** · {event['status']}")
            st.caption(event["summary"])


def readings(data, health):
    current = (data or {}).get("current")
    if not current:
        st.info(
            "No fresh reading is available. Older samples may still appear in history."
        )
        return
    fields = [
        ("heart_rate_bpm", "Pulse", "bpm"),
        ("spo2_percent", "Oxygen saturation", "%"),
        ("respiratory_rate_per_min", "Respiratory rate", "/min"),
        ("activity_level", "Activity", "0–1"),
    ]
    for col, (field, label, unit) in zip(st.columns(4), fields):
        col.metric(
            label,
            number(current[field], 2 if field == "activity_level" else 1),
            help=f"Synthetic {label.lower()}; unit {unit}. No diagnostic interpretation.",
        )
        col.caption(unit)
    st.caption(
        f"Simulated sample · {timestamp(current['measured_at'])} · freshness window {health.get('freshness_minutes', 120)} minutes"
    )


def history_chart(
    data, field="heart_rate_bpm", title="Pulse over seven days", color="#087E82"
):
    rows = (data or {}).get("history", [])
    if not rows:
        st.info("No historical samples are available for this profile.")
        return
    frame = pd.DataFrame(rows)
    frame["measured_at"] = pd.to_datetime(
        frame["measured_at"], format="ISO8601", utc=True
    )
    chart = (
        alt.Chart(frame)
        .mark_line(color=color, strokeWidth=2)
        .encode(
            x=alt.X(
                "measured_at:T",
                title=None,
                axis=alt.Axis(format="%d %b", labelAngle=0, tickCount=5),
            ),
            y=alt.Y(f"{field}:Q", title=title, scale=alt.Scale(zero=False)),
            tooltip=[
                alt.Tooltip(
                    "measured_at:T", title="Measured at", format="%d %b %H:%M UTC"
                ),
                alt.Tooltip(f"{field}:Q", title=title, format=".1f"),
            ],
        )
        .properties(height=210)
        .configure_view(stroke=None)
        .configure_axis(gridColor="#E3E9E8", labelColor="#4B606F", titleColor="#4B606F")
    )
    st.altair_chart(chart, width="stretch")


def sleep_chart(data):
    rows = (data or {}).get("sleep", [])
    if not rows:
        st.info("No sleep records are available.")
        return
    chart = (
        alt.Chart(pd.DataFrame(rows))
        .mark_bar(color="#416888", cornerRadiusTopLeft=3, cornerRadiusTopRight=3)
        .encode(
            x=alt.X("sleep_date:O", title=None, axis=alt.Axis(labelAngle=-25)),
            y=alt.Y("hours:Q", title="Sleep (hours)", scale=alt.Scale(zero=True)),
            tooltip=["sleep_date", alt.Tooltip("hours:Q", format=".1f")],
        )
        .properties(height=210)
        .configure_view(stroke=None)
        .configure_axis(gridColor="#E3E9E8", labelColor="#4B606F", titleColor="#4B606F")
    )
    st.altair_chart(chart, width="stretch")


def checkin(profile):
    st.subheader("A moment to check in")
    st.caption(
        "For this fictional profile. Notes stay in the local database and are not sent to the model."
    )
    with st.form(f"checkin_{profile}", border=False):
        mood = st.select_slider(
            "Mood today",
            options=[1, 2, 3, 4, 5],
            value=3,
            format_func=lambda n: {
                1: "Low",
                2: "A little low",
                3: "In between",
                4: "Fairly good",
                5: "Good",
            }[n],
        )
        note = st.text_input(
            "Optional note",
            max_chars=2000,
            placeholder="Use fictional details for the demo",
        )
        if st.form_submit_button("Save check-in"):
            if api(
                "POST",
                f"/profiles/{profile}/check-ins",
                json={"mood": mood, "note": note},
            ):
                st.success("Check-in saved")
    saved = api("GET", f"/profiles/{profile}/check-ins")
    if isinstance(saved, list) and saved:
        latest = saved[0]
        st.caption(
            f"Latest check-in · mood {latest['mood']}/5 · {timestamp(latest.get('recorded_at'))}"
        )
        if latest.get("note"):
            st.write(latest["note"])
    else:
        st.caption("No check-ins yet. A note is always optional.")


def overview(profile, name, data, health):
    st.title(f"A little context, {name}.")
    st.write(
        "Explore the fictional readings, choose what to share, and find support with sources you can inspect."
    )
    a, b, _ = st.columns([1, 1, 2])
    a.button(
        "Open AI Companion",
        type="primary",
        on_click=navigate,
        args=("AI Companion",),
        width="stretch",
    )
    b.button(
        "Compare A/B/C", on_click=navigate, args=("Comparison Lab",), width="stretch"
    )
    st.divider()
    st.subheader("Current simulated readings")
    readings(data, health)
    left, right = st.columns([1.6, 1], gap="large")
    with left:
        st.subheader("The past seven days")
        history_chart(data)
        st.caption(
            "A pulse trend describes measurements. It does not measure mood or establish a cause."
        )
    with right:
        checkin(profile)


def companion(profile, mode, consent, backend, workflow):
    st.title("AI Companion")
    st.write(
        "Talk through what is on your mind. Guidance is optional, and you can inspect every selected source."
    )
    labels = {
        "text_only": "Message and verified guidance only",
        "current_vitals": "Message, guidance and consented current readings",
        "full_context": "Message, guidance and consented current readings plus seven-day history",
    }
    st.info(
        labels[mode]
        + (
            " · physiological access is off until you consent"
            if mode != "text_only" and not consent
            else ""
        )
    )
    if backend == "live":
        st.caption(
            "Your message and permitted simulated context are sent to Groq. Use fictional details for this demonstration."
        )
    elif backend == "local":
        st.caption(
            "Local deterministic selection from verified passages. No language model or external API call."
        )
    else:
        st.warning(
            "Test mock: this checks application wiring and does not generate grounded AI guidance."
        )
    key = f"chat:{profile}:{mode}:{consent}:{backend}:{workflow}"
    messages = st.session_state.setdefault(key, [])
    session = st.session_state.setdefault(key + ":session", uuid.uuid4().hex)
    st.button(
        "Start a fresh conversation",
        on_click=lambda: (
            st.session_state.pop(key, None),
            st.session_state.pop(key + ":session", None),
        ),
    )
    welcome = st.empty()
    if not messages:
        with welcome.container():
            st.subheader("Where would you like to begin?")
            st.caption(
                "Try “I am stressed about exams and sleeping poorly” or “Could I choose a grounding exercise?”"
            )
    for message in messages:
        with st.chat_message(message["role"]):
            show_response(message["response"]) if message[
                "role"
            ] == "assistant" else st.write(message["text"])
    prompt = st.chat_input("What would you like support with?", max_chars=10000)
    if prompt:
        welcome.empty()
        messages.append({"role": "user", "text": prompt})
        with st.chat_message("user"):
            st.write(prompt)
        # Submit every message: the API owns urgent routing before consent checks.
        with st.chat_message("assistant"):
            with st.spinner(
                "Retrieving guidance and preparing a response…", show_time=True
            ):
                response = api(
                    "POST",
                    "/chat",
                    params={"backend": backend, "workflow": workflow},
                    json={
                        "session_id": session,
                        "profile_id": profile,
                        "message": prompt,
                        "mode": mode,
                        "consent_to_use_vitals": consent,
                    },
                )
            if response:
                messages.append({"role": "assistant", "response": response})
                show_response(response)


def comparison(profile, consent, backend, workflow):
    st.title("One question. Three views of context.")
    st.write(
        "Keep the message, model and knowledge base fixed. Compare what changes when the assistant can see more authorized information."
    )
    with st.form("comparison", border=False):
        prompt = st.text_area(
            "Shared message for A/B/C",
            value="I'm stressed about exams and sleeping poorly. Could we look at recent patterns?",
            max_chars=10000,
            height=110,
        )
        st.caption(
            "A: no physiology · B: current readings · C: current readings + seven-day history. Each run starts fresh."
        )
        submitted = st.form_submit_button("Run comparison", type="primary")
    key = f"comparison:{profile}:{consent}:{backend}:{workflow}"
    if submitted:
        if not prompt.strip():
            st.error("Enter a message to compare.")
        else:
            with st.spinner(
                "Running three isolated modes against one context snapshot…",
                show_time=True,
            ):
                result = api(
                    "POST",
                    "/compare",
                    params={"backend": backend, "workflow": workflow},
                    json={
                        "session_id": uuid.uuid4().hex,
                        "profile_id": profile,
                        "message": prompt,
                        "mode": "full_context",
                        "consent_to_use_vitals": consent,
                    },
                )
            if result:
                st.session_state[key] = result
    result = st.session_state.get(key)
    if result:
        st.caption(
            f"Synthetic snapshot · {timestamp(result['snapshot_at'])} · Run {result['run_id'][:8]}"
        )
        if result["evidence_comparison_applicable"]:
            (st.success if result["identical_rag_evidence"] else st.warning)(
                "Same retrieved evidence in all three modes"
                if result["identical_rag_evidence"]
                else "Retrieved evidence differs or a retrieval failed. This comparison is not fully controlled."
            )
        else:
            st.info(
                "Evidence equality could not be measured for this run. Inspect the tool activity and outcomes."
            )
        for col, label, row in zip(
            st.columns(3, gap="medium"), MODES, result["results"]
        ):
            with col:
                st.subheader(label)
                st.caption(
                    {
                        "text_only": "No physiological access",
                        "current_vitals": "Current readings only",
                        "full_context": "Current readings and seven-day history",
                    }[row["mode"]]
                )
                if row["response"]:
                    show_response(row["response"], {"Outcome": row["outcome"]})
                else:
                    st.error(row["error"])
        with st.expander("Comparison record"):
            st.json(result)
    else:
        st.info(
            "Ready to compare. Enter a shared message and choose Run comparison."
            if consent
            else "Enable simulated-vitals consent in the sidebar to compare ordinary requests. Urgent support remains available without consent."
        )
    st.caption(
        "More context does not necessarily produce better support. Source identity is checked; relevance and response quality still need human review."
    )


def health_context(data, health):
    st.title("Health Context")
    st.write(
        "A transparent view of the synthetic data behind this profile. These measurements cannot diagnose a condition."
    )
    readings(data, health)
    summary = (data or {}).get("summary", {})
    st.subheader("Seven-day data quality")
    status = (
        "Stale or incomplete current context"
        if summary.get("data_stale", True)
        else "Recent data available"
    )
    st.write(
        f"{summary.get('sample_count', 0)} samples · {number(100 * summary.get('missing_fraction', 1))}% missing expected fields · {status}"
    )
    a, b = st.columns(2, gap="large")
    with a:
        history_chart(data)
        st.caption(f"Mean pulse: {number(summary.get('mean_heart_rate_bpm'))} bpm")
    with b:
        sleep_chart(data)
        st.caption(
            f"Earlier sleep average: {number(summary.get('earlier_sleep_avg_hours'))} h · Recent: {number(summary.get('recent_sleep_avg_hours'))} h"
        )
    a, b = st.columns(2, gap="large")
    with a:
        history_chart(data, "spo2_percent", "Oxygen saturation (%)", "#416888")
    with b:
        history_chart(data, "respiratory_rate_per_min", "Respiratory rate (/min)")
    with st.expander("Inspect exact values and timestamps"):
        st.json(summary)
        st.dataframe(
            pd.DataFrame((data or {}).get("history", [])),
            hide_index=True,
            width="stretch",
        )


def evidence_page():
    st.title("Evidence & Evaluation")
    st.write(
        "Inspect the knowledge behind the guidance, and distinguish measured engineering results from unreviewed answer quality."
    )
    data = api("GET", "/evidence")
    if not data:
        return
    st.subheader(
        f"{data['passage_count']} verified passages from {data['source_count']} documents"
    )
    st.caption(
        "WHO · NHS · NIMH. Original hybrid retrieval remains the default. Source review is recorded in the registry; no endorsement is implied."
    )
    with st.form("retrieval", border=False):
        query = st.text_input(
            "Try a retrieval query",
            value="How can I manage stress before an examination?",
            max_chars=2000,
        )
        submitted = st.form_submit_button("Retrieve verified passages")
    if submitted and query.strip():
        with st.spinner("Searching the local knowledge index…"):
            result = api("GET", "/guidance", params={"query": query})
        if result:
            st.caption(
                f"{len(result['passages'])} passages · {result['latency_ms']} ms · no language model used"
            )
            if not result["passages"]:
                st.info(
                    "No relevant evidence returned. The system has not filled the gap with an invented source."
                )
            for passage in result["passages"]:
                with st.expander(f"{passage['publisher']} · {passage['section']}"):
                    st.write(passage["text"])
                    source_list([passage])
                    st.caption(
                        f"Retrieval score: {passage['score']:.4f}. This is not a probability of correctness."
                    )
    with st.expander("Source registry"):
        for source in data["sources"]:
            st.markdown(f"**{source['publisher']} · {source['title']}**")
            st.caption(
                f"{source['passage_count']} passages · last checked {source['last_checked']}"
            )
            st.link_button("Open verified document", source["url"])
    st.subheader("Saved evaluation results")
    st.caption(
        "Historical artifacts, not scores for your current conversation. Human review is pending. These tests do not constitute clinical validation."
    )
    with st.expander("Fictional agent evaluation scenarios"):
        for case in data.get("scenarios", []):
            st.markdown(f"**{case['id']}** · {case['profile_id']}")
            st.write(case["message"])
        if not data.get("scenarios"):
            st.caption("The scenario dataset is not included in this installation.")
    for report in data["reports"]:
        with st.expander(report["label"]):
            st.caption(report["artifact"])
            st.json(report["summary"])
            if report["model"]:
                st.json(report["model"], expanded=False)


def main():
    st.set_page_config(
        page_title="MindSync AI",
        page_icon=":material/spa:",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    st.markdown(
        f"<style>{Path(__file__).with_name('style.css').read_text()}</style>",
        unsafe_allow_html=True,
    )
    health = api("GET", "/health")
    profiles = api("GET", "/profiles") if health else None
    if health:
        st.session_state["request_timeout_seconds"] = health.get(
            "request_timeout_seconds", 45
        )
    if not profiles:
        st.title("MindSync AI")
        st.info(
            "Start the local API using the setup guide, then refresh this page. No readings or responses have been generated."
        )
        st.button("Refresh data")
        return
    with st.sidebar:
        st.markdown("## MindSync")
        st.caption("Wellbeing, with evidence.")
        page = st.radio("Workspace", PAGES, key="page", label_visibility="collapsed")
        st.divider()
        names = {p["id"]: p["name"] for p in profiles}
        profile = st.selectbox("Synthetic profile", list(names), format_func=names.get)
        st.caption(next(p["scenario"] for p in profiles if p["id"] == profile))
        mode_label = st.selectbox("Conversation context", list(MODES))
        consent = st.checkbox(
            "Allow simulated vitals in chat", key=f"consent:{profile}"
        )
        st.caption(
            "Consent controls agent access. Viewing the dashboard does not share data with the model."
        )
        st.divider()
        backend = st.selectbox(
            "Response backend", list(BACKENDS), format_func=BACKENDS.get
        )
        workflow_label = st.selectbox(
            "Agent strategy",
            ["Guided · consistent tools", "Autonomous · experimental"],
            disabled=backend != "live",
        )
        workflow = (
            "guided"
            if backend != "live" or workflow_label.startswith("Guided")
            else "autonomous"
        )
        selected = next(
            (b for b in health.get("backends", []) if b["id"] == backend), {}
        )
        if selected.get("ready"):
            st.caption("Configured · " + (selected.get("model") or BACKENDS[backend]))
        else:
            st.warning(selected.get("reason", "Backend readiness not verified"))
        st.button("Refresh data", width="stretch")
    st.markdown(
        '<div class="app-status">Simulated data <span>Educational prototype · non-diagnostic</span></div>',
        unsafe_allow_html=True,
    )
    data = (
        api("GET", f"/profiles/{profile}/vitals")
        if page in {"Overview", "Health Context"}
        else None
    )
    if page == "Overview":
        overview(profile, names[profile], data, health)
    elif page == "AI Companion":
        companion(profile, MODES[mode_label], consent, backend, workflow)
    elif page == "Comparison Lab":
        comparison(profile, consent, backend, workflow)
    elif page == "Health Context":
        health_context(data, health)
    else:
        evidence_page()
    st.divider()
    st.caption(
        "MindSync is a wellbeing-support prototype, not a therapist or medical device. If there is immediate danger, seek local emergency or qualified human help. The app does not contact anyone for you."
    )


if __name__ == "__main__":
    main()
