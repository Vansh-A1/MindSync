"""Small curated choices grounded in unchanged WHO/NHS source passages."""

from __future__ import annotations
from copy import deepcopy

EXERCISES = {
    "grounding": {
        "id": "grounding",
        "title": "Notice and reconnect",
        "description": "An optional grounding practice adapted from the WHO summary.",
        "steps": [
            "Notice your thoughts and feelings.",
            "If comfortable, slow down and connect with your body: gently press your feet into the floor, stretch and breathe.",
            "Refocus on what is around you. Notice what you can see, hear, touch, taste or smell.",
            "Pay curious attention to where you are and what you are doing.",
        ],
        "duration_estimate": "One or two minutes, if you wish.",
        "chunk_id": "who-stress-guide:5ef2078a8f8dd87607a6",
    },
    "mindful_attention": {
        "id": "mindful_attention",
        "title": "Notice, name and refocus",
        "description": "An optional attention practice adapted from WHO unhooking guidance.",
        "steps": [
            "Notice when a difficult thought or feeling has caught your attention.",
            "Silently name it, for example: I notice a difficult thought.",
            "Refocus your attention on what you are doing and who is with you.",
        ],
        "duration_estimate": None,
        "chunk_id": "who-stress-guide:bd808eae617340f3de1c",
    },
    "worry_reflection": {
        "id": "worry_reflection",
        "title": "Set aside worry time",
        "description": "An optional reflection activity adapted from NHS worry-time guidance.",
        "steps": [
            "Choose a short period to write down worries.",
            "Use that time to consider the worries and possible solutions.",
            "If useful to you, try making this a regular part of your routine.",
        ],
        "duration_estimate": "About 10–15 minutes, as suggested by NHS guidance.",
        "chunk_id": "nhs-worries:1aa4bc96d207d4086be0",
    },
}


def get_support_exercise(exercise_type: str, *, catalog=None) -> dict:
    if exercise_type not in EXERCISES:
        raise ValueError("Choose grounding, mindful_attention or worry_reflection")
    if catalog is None:
        from mindsync.ai.tools import EvidenceCatalog

        catalog = EvidenceCatalog()
    result = deepcopy(EXERCISES[exercise_type])
    passage = catalog.passages[result["chunk_id"]]
    result["source"] = catalog.source_ref(passage.model_dump())
    result["evidence"] = passage.model_dump(mode="json")
    return result
