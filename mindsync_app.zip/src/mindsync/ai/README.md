# MindSync LangGraph agent — Phase 3 integration

The agent executes real Python tools through one bounded LangGraph `StateGraph`.
The RAG library, corpus, index settings and previous evaluation results remain
frozen at commit `39259ec`. The original hybrid retriever is still the default;
the existing advanced opt-in settings continue to work unchanged.

**Integration status:** Developer 1's shared foundation from `origin/main`
(`126c0148dc0e7a03462db9648754ae74e4ec9f38`) is merged unchanged. The public
`run_agent()` imports the actual Pydantic contracts and returns `AgentOutput`.
Contract, mode and consent tests run against those real definitions. The standalone
core remains available for isolated diagnostics, but is not needed for integration.
See the [live verification report](../../../evaluation/phase3_live_results/integration_report.md)
for measured results and remaining limitations.

## Run the public-interface demonstration

From the repository root, with the existing development environment:

```bash
export PYTHONPATH="$PWD/src"
export HF_HUB_OFFLINE=1
runtime/dev2-venv/bin/python -m mindsync.ai.agent \
  --message "I'm stressed about exams and sleeping poorly" \
  --profile student_a --mode full_context --consent-vitals \
  --mock
```

`--mock` explicitly selects a deterministic model fixture. It emits genuine
`AIMessage.tool_calls`; the graph executes the frozen RAG function and the fake
context provider, then sends `ToolMessage` results back to the model. The JSON
contains the reply, selected source references, sanitized tool events, simulation
flag. It visibly identifies mock use. Add `--standalone` only when you intentionally want the core dictionary and internal diagnostics.

Profiles: `student_a` (94 BPM; history mean 76 BPM; sleep 7.2 → 4.8 hours),
`student_b` (126 BPM after fictional activity; ordinary sleep history), and
`student_c` (missing/stale/incomplete records). These examples are not measurements
of real people. Use `--session stable-id` to name a conversation within a running
service; separate CLI processes have separate in-memory state.

The demo imports fixtures from `tests/ai/fake_context_provider.py` and therefore
runs from a repository checkout. It does not require a database, API or simulator.

If the RAG index or cached embedding model is absent, follow the existing
[unchanged RAG setup instructions](../rag/README.md). Agent tool errors are visible;
no index is rebuilt or model downloaded automatically by the agent.

## Public integration

```python
from mindsync.ai.agent import run_agent
from mindsync.contracts import ChatRequest

request = ChatRequest(
    session_id="conversation-1",
    profile_id="student_a",
    message="I'm stressed about exams and sleeping poorly",
    mode="full_context",
    consent_to_use_vitals=True,
)
output = await run_agent(request, context_provider)
```

The exact public boundary is:

```python
async def run_agent(request: ChatRequest, context_provider: ContextProvider) -> AgentOutput
```

It imports and validates the real shared `ChatRequest`, `SourceRef`, `ToolEvent`
and `AgentOutput`. The provider is called only through
`get_current_vitals(request.profile_id)` and
`get_history_summary(request.profile_id, days=7)`. Both async and sync provider
methods are supported. No model argument can select another profile.

The shared `VitalReading.activity_level` is a normalized number from zero to one.
The agent adapter and fictional fixtures follow that definition. The provider
protocol has synchronous methods; the executor also accepts asynchronous methods.
Tool events contain the exact shared fields `name`, `status` and `summary`;
permission and simulation details are included in the sanitized summary.

Set `MINDSYNC_AGENT=real` in Developer 1's platform configuration to select this
adapter. Route urgent requests through that platform's safety gate first.
Dependency coordination is recorded in [dependency requests](../../../docs/dependency-requests.md).
The source files from the shared foundation are unchanged.

## Execution and permissions

```mermaid
flowchart LR
  START --> LLM_AGENT
  LLM_AGENT --> DECISION{Structured tool calls?}
  DECISION -->|yes, within limits| TOOLS[Validate and execute tools]
  TOOLS -->|ToolMessages| LLM_AGENT
  DECISION -->|no / controlled failure| FINALIZE
  FINALIZE --> END
```

| Mode | Available tools with consent |
| --- | --- |
| `text_only` | `search_guidance`, `get_support_exercise` |
| `current_vitals` | Above plus `get_current_vitals` |
| `full_context` | Above plus `analyze_vitals_history` |

Without explicit consent, all modes expose only guidance/exercise tools. Only
permitted schemas reach the model, and the executor independently checks the
allowlist and Pydantic argument schemas. Empty/extra arguments, malformed calls,
wrong-profile provider responses, invalid values and missing results fail closed.
The model cannot browse, execute arbitrary Python or contact anyone.

Each request allows at most **four tool attempts and three execution rounds**.
Denied/invalid attempts consume the call budget. Extra calls are recorded as
rejected events and never executed. After the budget is exhausted, the model can
finalize from existing results; repeated calls produce a controlled fallback.
Default model/tool timeouts are 30/10 seconds. A synchronous operation already
running in a worker thread cannot be forcibly interrupted by Python; its late
result is discarded and cannot enter another request's state.

Current data older than ten minutes is labelled stale; timestamps more than five
minutes into the future are rejected. Numeric bounds validate data shape, not
medical normality. History statistics come directly from the provider: the agent
does not recreate history processing or infer causes/diagnoses.

## Model configuration

The installed adapter is `langchain-groq`; this phase uses its native structured
tool calling. Live credentials are read only from environment variables:

| Variable | Meaning |
| --- | --- |
| `MOCK_LLM` | Explicit `true` for the local fixture; default `false` |
| `LLM_MODEL` | Required live model ID; tested candidate `qwen/qwen3.8-27b` |
| `LLM_API_KEY` | Required secret supplied locally; never printed or committed |
| `LLM_BASE_URL` | Defaults to `https://api.groq.com/openai/v1` |

This adapter accepts the official Groq HTTPS endpoint. Another provider needs an
explicit adapter; an arbitrary endpoint is rejected. The same model and core
instructions are used across A/B/C, with temperature zero and no automatic
provider retries or model fallback. Free-tier availability/quotas depend on the user's
account; billing eligibility was not inspected or changed. Real structured tool
calls were tested using fictional data. GPT-OSS 20B and 120B also remain usable
through the environment selection, but had invalid-tool and citation-selection
failures in the recorded probes. Qwen uses `reasoning_effort=none` and hidden
reasoning. GPT-OSS uses low effort and `include_reasoning=false`. No reasoning
content is checkpointed or included in evaluation results.

Provider authentication, timeout, network, rate-limit and schema errors are
sanitized. A live failure never silently switches to the mock. Optional smoke
verification, after configuring the environment and cached RAG:

```bash
MOCK_LLM=false MINDSYNC_AGENT_LIVE_TEST=1 PYTHONPATH=src \
  runtime/dev2-venv/bin/pytest tests/ai/test_agent.py \
  -k real_provider_tool_smoke -q -o asyncio_default_fixture_loop_scope=function
```

## Evidence and output validation

`search_guidance(query)` calls the frozen `search_guidance(query, top_k=4)` and
returns full passage text, chunk/source IDs, publisher, title, section, URL and
score. An agent-owned catalogue checks exact passage identity against the frozen
verified registry. Only evidence returned during the current request can be cited.

The model returns a small internal JSON selection: an empathetic acknowledgement,
exact source excerpts, relevant successful context-tool names, and an optional
approved exercise ID. The server verifies current-request IDs and exact quotes,
and renders factual context/steps directly from validated tool results. Sources
are attached only to selected excerpts or the selected exercise. No reference is
attached just because retrieval found it. Empty/failed retrieval is acknowledged. If selection fails despite available passages,
the message describes a selection limitation, not a gap in the knowledge base.
The exercise tool supplies original source text separately from adapted steps.

A lightweight lexical relevance screen and output guard reject some unrelated
references and unsupported claims. They are **not** semantic entailment or clinical
validators. Valid identity/exact quotation does not prove relevance, completeness
or clinical appropriateness. Free-form acknowledgement screening is heuristic;
human review remains required even after live-provider checks. This conservative
quote-based presentation is an intentional prototype trade-off and may sound less
natural than unconstrained generated advice.

A rejected final JSON selection can receive **one** additional format-repair call
to the same model, with no tools bound. Its schema permits only observed context,
retrieved source IDs and approved exercises from that request. Identity, quotation
and permission checks still run after repair. Failure returns a controlled fallback;
repair counts and latency appear in evaluation diagnostics. A free-form acknowledgement
that fails the output guard is discarded as a whole; independently validated selected
context can still be rendered under a neutral introduction. This is not a semantic
proof that every other generated sentence is grounded.

Three approved exercises use existing frozen WHO/NHS evidence: grounding, mindful
attention/unhooking, and worry reflection. Activities are offered as choices and
can be stopped. No new source content or clinical treatment is added.

Developer 1 owns the pre-agent safety gate. A narrow defensive urgent-content
fallback directs toward human support if such a request reaches this graph. It
does not contact anyone, assess actual safety or validate platform emergency
routing. Joint platform safety tests remain outstanding.

## Session privacy

Checkpoints exist only in RAM. Thread keys include session ID, profile ID, mode,
consent and model configuration. Same-key requests serialize; different keys are
isolated. Each request receives its own provider through LangGraph runtime context.
Providers, keys and callbacks are not checkpointed. Remote LangSmith tracing is
explicitly disabled even if an ambient tracing variable is enabled.

At the next turn, prior checkpoints are pruned. At most five earlier user messages
and the previous brief conversational acknowledgement are carried forward;
previous tool results, numerical context and citation ledgers are not carried
forward. Fresh evidence must be retrieved again. Sessions expire lazily after
30 idle minutes or via bounded idle eviction (128 sessions by default).
`AgentService.forget_session(request, model)` explicitly deletes an idle session.
Process exit deletes all state. A/B/C evaluations use fresh independent IDs.

## Tests and evaluation

Fast tests need no API calls or model downloads:

```bash
PYTHONPATH=src runtime/dev2-venv/bin/pytest tests/ai/ -q \
  -o asyncio_default_fixture_loop_scope=function
```

Real agent-to-RAG integration with the cached model/index:

```bash
MINDSYNC_AGENT_REAL_RAG=1 HF_HUB_OFFLINE=1 PYTHONPATH=src \
  runtime/dev2-venv/bin/pytest tests/ai/test_agent.py tests/ai/test_graph.py \
  tests/ai/test_tools.py tests/ai/test_modes.py -q \
  -o asyncio_default_fixture_loop_scope=function
```

Run the frozen RAG model suite in a separate process:

```bash
MINDSYNC_RAG_REAL_TESTS=1 HF_HUB_OFFLINE=1 PYTHONPATH=src \
  runtime/dev2-venv/bin/pytest tests/ai/ --ignore=tests/ai/test_agent.py \
  --ignore=tests/ai/test_graph.py --ignore=tests/ai/test_tools.py \
  --ignore=tests/ai/test_modes.py -q -o asyncio_default_fixture_loop_scope=function
```

Its unchanged isolation assertion requires `langgraph` to be absent from
`sys.modules`; collecting agent tests in the same process invalidates that
assumption. The initial mixed opt-in failure is retained in the report. The
normal combined fast suite does not enable this model test.

Six scenarios × three modes, with actual RAG/tools and deterministic mock model:

```bash
HF_HUB_OFFLINE=1 PYTHONPATH=src runtime/dev2-venv/bin/python \
  evaluation/evaluate_agent.py --mock --output-dir runtime/agent-mock-evaluation
```

The new agent-only output directory contains responses, model configuration,
source IDs, observable tool traces, latency and deterministic checks. Human
relevance, groundedness and context-quality scores remain `null`/pending with a
review rubric. Mock results verify wiring and enforcement, not real LLM quality,
clinical performance, or a benefit from adding physiological context. Use a new
`--output-dir` for a later `--live` evaluation to preserve these mock results.

## Reproduce live checks

Supply `LLM_API_KEY` locally; never paste it into source files or committed commands.
For a temporary Bash session, `read -rs LLM_API_KEY; export LLM_API_KEY` accepts it
without echoing. Configure the model and run the public interface:

```bash
export LLM_MODEL=qwen/qwen3.8-27b
export LLM_BASE_URL=https://api.groq.com/openai/v1
export MOCK_LLM=false
export PYTHONPATH="$PWD/src"
export HF_HUB_OFFLINE=1
runtime/dev2-venv/bin/python evaluation/verify_live_agent.py \
  --output runtime/agent-live-controls.json --case-delay-seconds 30
runtime/dev2-venv/bin/python evaluation/evaluate_agent.py --live \
  --output-dir runtime/agent-live-evaluation --case-delay-seconds 30
```

The five controls and 18 scenario/mode runs use the actual public contracts and
fictional providers. They save responses, tool/source identities and latency.
Pacing is excluded from response latency. The evaluator preserves partial runs
if interrupted. Human scoring remains pending. A test succeeding once does not
establish reliability, clinical safety, or superiority of additional physiology.
