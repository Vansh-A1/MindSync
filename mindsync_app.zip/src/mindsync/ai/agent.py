"""Public shared-contract adapter and independently testable LangGraph service.

The production entrypoint imports Developer 1's real contracts. When they are
missing, the explicit --standalone demo tests the same graph core without
counterfeit contract classes or a claim of completed platform integration.
"""

from __future__ import annotations

import argparse
import asyncio
import copy
import hashlib
import importlib
import json
import os
import time
import uuid
import weakref
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from langchain_core.messages import HumanMessage, AIMessage
from langgraph.checkpoint.memory import InMemorySaver
from langsmith import tracing_context
from .state import RunDependencies
from .graph import build_graph
from .model import create_model, ProviderError
from .tools import EvidenceCatalog, build_tools, mode_value, permitted_tools
from .prompts import (
    SUPPORT_FALLBACK,
    URGENT_FALLBACK,
    SCOPE_FALLBACK,
    requires_human_support,
    outside_clinical_scope,
)

WORKFLOW_OVERRIDE = ContextVar("mindsync_workflow", default=None)
LAST_RUN_DIAGNOSTICS = ContextVar("mindsync_last_run_diagnostics", default=None)


class RequestDiagnostics(dict):
    """An explicit API request sink, also visible to its wait_for child task."""


try:
    from mindsync.contracts import ChatRequest, ContextProvider, AgentOutput
except ModuleNotFoundError as exc:
    # No aliases or substitutes: only the standalone core is usable without A's file.
    if exc.name != "mindsync.contracts":
        raise


class MissingContractsError(RuntimeError):
    pass


class SessionCapacityError(RuntimeError):
    pass


def shared_contracts():
    try:
        module = importlib.import_module("mindsync.contracts")
    except ModuleNotFoundError as exc:
        if exc.name != "mindsync.contracts":
            raise
        raise MissingContractsError(
            "Developer 1 must provide src/mindsync/contracts.py. No replacement contracts were created. Use --standalone --mock only to demonstrate the independently tested graph core."
        ) from exc
    required = [
        "ChatRequest",
        "AgentOutput",
        "SourceRef",
        "ToolEvent",
        "ContextProvider",
        "VitalReading",
        "HistorySummary",
        "Mode",
    ]
    missing = [name for name in required if not hasattr(module, name)]
    if missing:
        raise MissingContractsError(
            "Shared contracts are missing: " + ", ".join(missing)
        )
    return module


def validate_request_shape(request):
    for name, limit in [("session_id", 100), ("profile_id", 100), ("message", 10000)]:
        value = getattr(request, name, None)
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise ValueError(f"Invalid request {name}")
    permitted_tools(request)


@dataclass
class SessionRecord:
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    last_used: float = field(default_factory=time.monotonic)
    users: int = 0


class AgentService:
    """RAM-only checkpoints; bounded sessions and serialized turns per identity.

    No ContextProvider is stored globally or in checkpoints. Runtime dependencies
    are passed separately to each graph invocation. Completed prior checkpoints
    are pruned before the next turn; only bounded conversation messages carry on.
    """

    def __init__(
        self,
        *,
        catalog=None,
        lookup=None,
        max_sessions=128,
        ttl_seconds=1800,
        tool_timeout_seconds=10.0,
        model_timeout_seconds=30.0,
        now=None,
        workflow="autonomous",
    ):
        if workflow not in {"autonomous", "guided"}:
            raise ValueError("AGENT_WORKFLOW must be autonomous or guided")
        self.workflow = workflow
        if (
            type(max_sessions) is not int
            or max_sessions < 1
            or ttl_seconds <= 0
            or tool_timeout_seconds <= 0
            or model_timeout_seconds <= 0
        ):
            raise ValueError("Session capacity and timeouts must be positive")
        self.catalog = catalog or EvidenceCatalog()
        self.lookup = lookup
        self.checkpointer = InMemorySaver()
        if workflow == "guided":
            from .guided import build_guided_graph

            self.graph = build_guided_graph(self.checkpointer)
        else:
            self.graph = build_graph(self.checkpointer)
        self.sessions = {}
        self.registry_lock = asyncio.Lock()
        self.max_sessions = max_sessions
        self.ttl_seconds = ttl_seconds
        self.tool_timeout_seconds = tool_timeout_seconds
        self.model_timeout_seconds = model_timeout_seconds
        self.now = now or (lambda: datetime.now(timezone.utc))

    def thread_key(self, request, model):
        identity = [
            request.session_id,
            request.profile_id,
            mode_value(request),
            request.consent_to_use_vitals,
            model.configuration,
            self.workflow,
        ]
        return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()

    async def _session(self, key):
        async with self.registry_lock:
            now = time.monotonic()
            expired = [
                k
                for k, r in self.sessions.items()
                if not r.users and now - r.last_used > self.ttl_seconds
            ]
            for k in expired:
                await self.checkpointer.adelete_thread(k)
                del self.sessions[k]
            if key not in self.sessions and len(self.sessions) >= self.max_sessions:
                idle = [k for k, r in self.sessions.items() if not r.users]
                if not idle:
                    raise SessionCapacityError("Agent session capacity reached")
                oldest = min(idle, key=lambda k: self.sessions[k].last_used)
                await self.checkpointer.adelete_thread(oldest)
                del self.sessions[oldest]
            record = self.sessions.setdefault(key, SessionRecord())
            record.users += 1
            return record

    async def forget_session(self, request, model):
        key = self.thread_key(request, model)
        async with self.registry_lock:
            record = self.sessions.get(key)
            if record and record.users:
                raise RuntimeError("Session has active requests")
            await self.checkpointer.adelete_thread(key)
            self.sessions.pop(key, None)

    async def run_core(self, request, context_provider, *, model=None) -> dict:
        """Independent transport: dict payload plus diagnostics, NOT shared AgentOutput."""
        validate_request_shape(request)
        request = copy.deepcopy(request)
        if model is None:
            try:
                model = create_model(workflow=self.workflow)
            except ProviderError as exc:
                code = exc.code
                if requires_human_support(request.message):
                    reply, code = URGENT_FALLBACK, "urgent_support"
                elif outside_clinical_scope(request.message):
                    reply, code = SCOPE_FALLBACK, "clinical_scope"
                else:
                    reply = (
                        f"The language model is unavailable ({code}). "
                        + SUPPORT_FALLBACK
                    )
                return {
                    "output": {
                        "reply": reply,
                        "sources": [],
                        "tool_trace": [],
                        "simulated_data_used": False,
                    },
                    "diagnostics": {
                        "terminal_reason": code,
                        "model": {"mock": False, "provider": "unconfigured"},
                        "tool_call_count": 0,
                        "tool_rounds": 0,
                        "model_calls": 0,
                        "latency_ms": 0.0,
                    },
                }
        start = time.perf_counter()
        key = self.thread_key(request, model)
        try:
            record = await self._session(key)
        except SessionCapacityError:
            return {
                "output": {
                    "reply": ("[Mock model demonstration] " if model.is_mock else "")
                    + "The assistant is busy. Please try again shortly.",
                    "sources": [],
                    "tool_trace": [],
                    "simulated_data_used": False,
                },
                "diagnostics": {
                    "terminal_reason": "session_capacity",
                    "model": model.configuration,
                    "tool_call_count": 0,
                    "tool_rounds": 0,
                    "model_calls": 0,
                    "finalization_repairs": 0,
                    "latency_ms": (time.perf_counter() - start) * 1000,
                },
            }
        try:
            async with record.lock:
                config = {
                    "configurable": {"thread_id": key},
                    "recursion_limit": 12,
                    "callbacks": [],
                }
                previous = await self.graph.aget_state(config)
                history = []
                if previous.values:
                    # No old ToolMessages, source ledger or physiological tool results are reused.
                    history = [
                        m
                        for m in previous.values.get("messages", [])
                        if isinstance(m, HumanMessage)
                    ][-5:]
                    prior = previous.values.get("output", {}).get("reply")
                    if prior:
                        # Keep conversational continuity without old readings, quotes or source IDs.
                        first = prior.split("\n\n")[0]
                        history.append(AIMessage(content=first))
                await self.checkpointer.adelete_thread(key)
                state = {
                    "messages": [
                        *history,
                        HumanMessage(content=request.message, id=uuid.uuid4().hex),
                    ],
                    "tool_call_count": 0,
                    "tool_rounds": 0,
                    "evidence": {},
                    "tool_trace": [],
                    "context_results": {},
                    "exercises": {},
                    "simulated_data_used": False,
                    "terminal_reason": None,
                    "output": {},
                    "model_calls": 0,
                    "finalization_repairs": 0,
                    "acknowledgement_replaced": False,
                    "guided_results": {},
                    "guided_evidence": {},
                    "rag_evidence_ids": [],
                    "rag_fingerprint": None,
                    "generation_outcome": "not_generated",
                    "validation_error": None,
                    "rejected_selections": [],
                    "generation_attempts": [],
                }
                tools = build_tools(
                    request,
                    context_provider,
                    self.catalog,
                    lookup=self.lookup,
                    now=self.now,
                )
                ctx = RunDependencies(
                    request=request,
                    context_provider=context_provider,
                    model=model,
                    tools=tools,
                    catalog=self.catalog,
                    permitted_tools=permitted_tools(request),
                    run_id=uuid.uuid4().hex,
                    now=self.now,
                    tool_timeout_seconds=self.tool_timeout_seconds,
                    model_timeout_seconds=self.model_timeout_seconds,
                )
                try:
                    with tracing_context(enabled=False):
                        result = await self.graph.ainvoke(state, config, context=ctx)
                except Exception:
                    # Do not expose provider data, internal exception details or incomplete checkpoints.
                    await self.checkpointer.adelete_thread(key)
                    result = {
                        **state,
                        "terminal_reason": "graph_failure",
                        "output": {
                            "reply": (
                                "[Mock model demonstration] " if model.is_mock else ""
                            )
                            + SUPPORT_FALLBACK,
                            "sources": [],
                            "tool_trace": [],
                            "simulated_data_used": False,
                        },
                    }
                return {
                    "output": result["output"],
                    "diagnostics": {
                        "terminal_reason": result["terminal_reason"],
                        "model": model.configuration,
                        "tool_call_count": result["tool_call_count"],
                        "tool_rounds": result["tool_rounds"],
                        "model_calls": result["model_calls"],
                        "finalization_repairs": result.get("finalization_repairs", 0),
                        "acknowledgement_replaced": result.get(
                            "acknowledgement_replaced", False
                        ),
                        "latency_ms": (time.perf_counter() - start) * 1000,
                        "thread_id": key,
                        "evidence_ids": sorted(result["evidence"]),
                        "permitted_tools": sorted(ctx.permitted_tools),
                        "workflow": self.workflow,
                        "context_results": result["context_results"],
                        **{
                            field: result.get(field)
                            for field in (
                                "rag_evidence_ids",
                                "rag_fingerprint",
                                "generation_outcome",
                                "rejected_selections",
                                "generation_attempts",
                                "validation_error",
                            )
                        },
                    },
                }
        finally:
            async with self.registry_lock:
                record.users -= 1
                record.last_used = time.monotonic()


_SERVICES: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()


def service_for_current_loop():
    loop = asyncio.get_running_loop()
    workflow = WORKFLOW_OVERRIDE.get() or os.environ.get("AGENT_WORKFLOW", "autonomous")
    if loop not in _SERVICES:
        _SERVICES[loop] = {}
    if workflow not in _SERVICES[loop]:
        _SERVICES[loop][workflow] = AgentService(workflow=workflow)
    return _SERVICES[loop][workflow]


async def run_agent(
    request: ChatRequest, context_provider: ContextProvider
) -> AgentOutput:
    """Exact public contract boundary; requires the actual shared Pydantic models."""
    from mindsync.config import Settings

    diagnostics_holder = LAST_RUN_DIAGNOSTICS.get()
    if not isinstance(diagnostics_holder, RequestDiagnostics):
        diagnostics_holder = {}
        LAST_RUN_DIAGNOSTICS.set(diagnostics_holder)
    else:
        diagnostics_holder.clear()
    contracts = shared_contracts()
    if not isinstance(request, contracts.ChatRequest):
        raise TypeError("run_agent requires the shared ChatRequest")
    # Revalidate even model_construct()-created input before trusting permissions.
    request = contracts.ChatRequest.model_validate(request.model_dump())
    try:
        result = await asyncio.wait_for(
            service_for_current_loop().run_core(request, context_provider),
            timeout=Settings.from_env().agent_timeout_seconds,
        )
    except TimeoutError:
        diagnostics_holder.update(
            {"terminal_reason": "request_timeout", "generation_outcome": "fallback"}
        )
        raise
    diagnostics_holder.update(result["diagnostics"])
    data = result["output"]
    refs = [contracts.SourceRef.model_validate(source) for source in data["sources"]]
    events = []
    for event in data["tool_trace"]:
        fields = contracts.ToolEvent.model_fields
        public_event = {k: v for k, v in event.items() if k in fields}
        if not {"permitted", "simulated_context_used"} <= fields.keys():
            public_event["summary"] += (
                f" [permitted={event['permitted']}; simulated_context_used={event['simulated_context_used']}]"
            )
        events.append(contracts.ToolEvent.model_validate(public_event))
    return contracts.AgentOutput(
        reply=data["reply"],
        sources=refs,
        tool_trace=events,
        simulated_data_used=data["simulated_data_used"],
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--message", required=True)
    parser.add_argument(
        "--profile",
        choices=["student_a", "student_b", "student_c"],
        default="student_a",
    )
    parser.add_argument(
        "--mode",
        choices=["text_only", "current_vitals", "full_context"],
        default="text_only",
    )
    parser.add_argument("--consent-vitals", action="store_true")
    parser.add_argument("--session", default=None)
    parser.add_argument("--workflow", choices=["autonomous", "guided"], default=None)
    parser.add_argument(
        "--mock",
        action="store_true",
        help="Explicit deterministic mock model; real Python tools still execute.",
    )
    parser.add_argument(
        "--standalone",
        action="store_true",
        help="Use plain fixtures and the same graph core while shared contracts are absent; output is NOT AgentOutput.",
    )
    args = parser.parse_args(argv)
    # Fixtures are deliberately kept outside production/shared contracts.
    from importlib.util import spec_from_file_location, module_from_spec

    path = Path(__file__).resolve().parents[3] / "tests/ai/fake_context_provider.py"
    spec = spec_from_file_location("mindsync_demo_fixtures", path)
    fixtures = module_from_spec(spec)
    spec.loader.exec_module(fixtures)
    provider = fixtures.FakeContextProvider(now=datetime.now(timezone.utc))
    data = {
        "session_id": args.session or uuid.uuid4().hex,
        "profile_id": args.profile,
        "message": args.message,
        "mode": args.mode,
        "consent_to_use_vitals": args.consent_vitals,
    }
    if args.mock:
        os.environ["MOCK_LLM"] = "true"
    if args.workflow:
        os.environ["AGENT_WORKFLOW"] = args.workflow

    async def demo():
        if args.standalone:
            from types import SimpleNamespace

            result = await AgentService(
                workflow=os.environ.get("AGENT_WORKFLOW", "autonomous")
            ).run_core(SimpleNamespace(**data), provider)
            return {
                "contract_status": "STANDALONE: shared contracts not integrated",
                **result,
            }
        contracts = shared_contracts()
        result = await run_agent(contracts.ChatRequest.model_validate(data), provider)
        return {
            "contract_status": "shared_contracts",
            "model": create_model().configuration,
            "output": result.model_dump(mode="json"),
        }

    try:
        print(json.dumps(asyncio.run(demo()), indent=2, ensure_ascii=False))
        return 0
    except (MissingContractsError, ValueError, ProviderError) as exc:
        parser.exit(2, str(exc) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
