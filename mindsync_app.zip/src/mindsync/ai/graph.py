"""One bounded LangGraph agent with real StructuredTool execution and final validation."""

from __future__ import annotations

import asyncio
import json
import re
from typing import Literal
from langchain_core.messages import AIMessage, SystemMessage, ToolMessage
from langgraph.graph import StateGraph, START, END
from langgraph.runtime import Runtime
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .state import AgentState, RunDependencies
from .prompts import (
    SYSTEM_PROMPT,
    SUPPORT_FALLBACK,
    URGENT_FALLBACK,
    SCOPE_FALLBACK,
    requires_human_support,
    outside_clinical_scope,
    unsafe_draft,
)
from .model import ProviderError
from .tools import ToolDataError, permitted_tools


class CitationSelection(BaseModel):
    model_config = ConfigDict(extra="forbid")
    chunk_id: str = Field(min_length=1, max_length=160)
    quote: str = Field(min_length=8, max_length=600)


class FinalDraft(BaseModel):
    """Internal model-output grammar; not a replacement for shared AgentOutput."""

    model_config = ConfigDict(extra="forbid")
    reply: str = Field(min_length=1, max_length=1600)
    citations: list[CitationSelection] = Field(default_factory=list, max_length=3)
    context_tools: list[Literal["get_current_vitals", "analyze_vitals_history"]] = (
        Field(default_factory=list, max_length=2)
    )
    exercise_id: (
        Literal["grounding", "mindful_attention", "worry_reflection"] | None
    ) = None


def fallback(state, ctx, reason):
    reply = (
        URGENT_FALLBACK
        if reason == "urgent_support"
        else SCOPE_FALLBACK
        if reason == "clinical_scope"
        else SUPPORT_FALLBACK
    )
    notices = {
        "authentication_failed": "The language-model credentials were rejected.",
        "rate_limited": "The language-model rate limit was reached.",
        "provider_timeout": "The language-model request timed out.",
        "network_failure": "The language-model service could not be reached.",
        "model_or_tool_schema_rejected": "The provider rejected the configured model or tool schema.",
        "invalid_tool_generation": "The model produced an invalid tool request; it was not executed.",
        "tool_limit_reached": "The tool-execution limit was reached; I have not invented missing results.",
        "final_validation_failed": "I could not verify the generated response or its references.",
    }
    if reason in notices:
        reply = notices[reason] + " " + reply
    if ctx.model.is_mock:
        reply = "[Mock model demonstration] " + reply
    return {
        "reply": reply,
        "sources": [],
        "tool_trace": state.get("tool_trace", []),
        "simulated_data_used": state.get("simulated_data_used", False),
    }


async def llm_agent(state: AgentState, runtime: Runtime[RunDependencies]):
    ctx = runtime.context
    if requires_human_support(ctx.request.message):
        return {"terminal_reason": "urgent_support"}
    if outside_clinical_scope(ctx.request.message):
        return {"terminal_reason": "clinical_scope"}
    budget_available = (
        state["tool_call_count"] < ctx.max_tool_calls
        and state["tool_rounds"] < ctx.max_tool_rounds
    )
    tools = list(ctx.tools.values()) if budget_available else []
    instruction = SYSTEM_PROMPT
    instruction += (
        "\nTools available for this request: "
        + (", ".join(sorted(t.name for t in tools)) or "none")
        + "."
    )
    if not budget_available:
        instruction += "\nTool budget exhausted. Return final JSON using only this turn's existing results, or acknowledge the limitation."
    try:
        message = await asyncio.wait_for(
            ctx.model.ainvoke(
                [SystemMessage(content=instruction), *state["messages"]], tools
            ),
            ctx.model_timeout_seconds,
        )
        if not isinstance(message, AIMessage):
            raise ProviderError("unsupported_model_response")
        if message.invalid_tool_calls:
            raise ProviderError("malformed_tool_call")
        if len(message.tool_calls) > 8:
            raise ProviderError("excessive_tool_batch")
        ids = [t.get("id") for t in message.tool_calls]
        if any(
            not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,63}", t.get("name", ""))
            for t in message.tool_calls
        ):
            raise ProviderError("invalid_tool_name")
        if any(not isinstance(i, str) or not i or len(i) > 160 for i in ids) or len(
            ids
        ) != len(set(ids)):
            raise ProviderError("invalid_tool_call_ids")
        if any(
            not isinstance(t.get("args"), dict) or len(json.dumps(t["args"])) > 8192
            for t in message.tool_calls
        ):
            raise ProviderError("malformed_tool_arguments")
        return {"messages": [message], "model_calls": state["model_calls"] + 1}
    except asyncio.TimeoutError:
        return {
            "terminal_reason": "provider_timeout",
            "model_calls": state["model_calls"] + 1,
        }
    except ProviderError as exc:
        return {"terminal_reason": exc.code, "model_calls": state["model_calls"] + 1}
    except Exception:
        return {
            "terminal_reason": "provider_failure",
            "model_calls": state["model_calls"] + 1,
        }


def tool_decision(state: AgentState):
    if state.get("terminal_reason"):
        return "finalize"
    last = state["messages"][-1]
    return (
        "tool_execution"
        if isinstance(last, AIMessage) and last.tool_calls
        else "finalize"
    )


async def tool_execution(state: AgentState, runtime: Runtime[RunDependencies]):
    ctx = runtime.context
    calls = state["messages"][-1].tool_calls
    count = state["tool_call_count"]
    rounds = state["tool_rounds"]
    trace = list(state["tool_trace"])
    evidence = dict(state["evidence"])
    contexts = dict(state["context_results"])
    exercises = dict(state["exercises"])
    simulated = state["simulated_data_used"]
    messages = []
    terminal = None
    # Executor checks independently of the schemas shown to the model.
    allowed = permitted_tools(ctx.request) & ctx.permitted_tools
    for call in calls:
        name = call["name"]
        permitted = name in allowed and name in ctx.tools
        status = "error"
        payload = {"ok": False, "error": "tool_not_permitted"}
        summary = "Tool denied by mode/consent allowlist; permitted=False."
        used_simulated = False
        if count >= ctx.max_tool_calls or rounds >= ctx.max_tool_rounds:
            payload = {"ok": False, "error": "tool_limit_reached"}
            summary = "Tool not executed: request budget exhausted."
            terminal = "tool_limit_reached"
        else:
            count += 1
            if permitted:
                try:
                    # Revalidation here prevents hidden profile IDs or extra arguments.
                    args = (
                        ctx.tools[name]
                        .args_schema.model_validate(call["args"])
                        .model_dump()
                    )
                    result = await asyncio.wait_for(
                        ctx.tools[name].ainvoke(args, config={"callbacks": []}),
                        ctx.tool_timeout_seconds,
                    )
                    if (
                        not isinstance(result, dict)
                        or not {"data", "evidence", "summary", "simulated"}
                        <= result.keys()
                    ):
                        raise ToolDataError("Missing tool result")
                    checked = [
                        ctx.catalog.validate(item) for item in result["evidence"]
                    ]
                    for item in checked:
                        evidence[item["chunk_id"]] = item
                    payload = {"ok": True, "data": result["data"]}
                    status = "ok"
                    summary = result["summary"]
                    used_simulated = bool(result["simulated"])
                    simulated |= used_simulated
                    if name in {"get_current_vitals", "analyze_vitals_history"}:
                        contexts[name] = result["data"]
                    if name == "get_support_exercise":
                        exercises[result["data"]["id"]] = result["data"]
                except asyncio.TimeoutError:
                    payload = {"ok": False, "error": "tool_timeout"}
                    summary = "Permitted tool timed out; no reliable result."
                except ValidationError:
                    payload = {"ok": False, "error": "invalid_arguments"}
                    summary = (
                        "Permitted tool rejected invalid/extra arguments; not executed."
                    )
                except PermissionError:
                    payload = {"ok": False, "error": "tool_not_permitted"}
                    summary = "Tool denied by independent authorization check."
                except Exception:
                    payload = {"ok": False, "error": "tool_unavailable"}
                    summary = "Permitted tool failed or returned invalid data; no reliable result."
        trace.append(
            {
                "name": name,
                "status": status,
                "summary": summary,
                "permitted": permitted,
                "simulated_context_used": used_simulated,
            }
        )
        messages.append(
            ToolMessage(
                content=json.dumps(payload, ensure_ascii=False),
                name=name,
                tool_call_id=call["id"],
                status="success" if status == "ok" else "error",
            )
        )
    return {
        "messages": messages,
        "tool_call_count": count,
        "tool_rounds": min(rounds + 1, ctx.max_tool_rounds),
        "tool_trace": trace,
        "evidence": evidence,
        "context_results": contexts,
        "exercises": exercises,
        "simulated_data_used": simulated,
        "terminal_reason": terminal,
    }


def after_tools(state: AgentState):
    return "finalize" if state.get("terminal_reason") else "llm_agent"


def relevant_overlap(query: str, quote: str) -> bool:
    # A conservative lexical screening check, not an entailment or clinical validator.
    ignored = set(
        "the and this that with have what how can could should would about feel feeling help please want some when where which like doing from your does there even though are was for has not but all our just".split()
    )

    def tokens(text):
        return {
            w[:5] for w in re.findall(r"[a-z]{3,}", text.lower()) if w not in ignored
        }

    return bool(tokens(query) & tokens(quote))


def render_context(name: str, data: dict) -> str:
    label = "Fictional simulated data" if data.get("simulated") else "Recorded data"
    if not data["available"]:
        return data["reason"]
    if name == "get_current_vitals":
        if data["data_stale"]:
            return f"{label}: the available reading is stale ({data['measured_at']}); it is not a current measurement."
        values = []
        for key, title, unit in [
            ("heart_rate_bpm", "heart rate", "BPM"),
            ("spo2_percent", "SpO2", "%"),
            ("respiratory_rate_per_min", "respiratory rate", "per minute"),
        ]:
            if data[key] is not None:
                values.append(f"{title} {data[key]} {unit}")
        if data.get("activity_level") is not None:
            values.append(
                f"activity level {data['activity_level']} on a zero-to-one scale"
            )
        missing = (
            " Some measurement fields are missing." if data["missing_fields"] else ""
        )
        return f"{label} at {data['measured_at']}: {', '.join(values) or 'no usable measurements'}.{missing} These readings do not establish a diagnosis or whether someone is safe."
    if data["data_stale"]:
        return f"{label}: the seven-day summary is stale and incomplete or unavailable for current interpretation; I have not inferred a trend from it."
    values = [
        f"{data['sample_count']} samples",
        f"missing fraction {data['missing_fraction']}",
    ]
    for key, title in [
        ("mean_heart_rate_bpm", "mean heart rate (BPM)"),
        ("earlier_sleep_avg_hours", "earlier sleep average (hours)"),
        ("recent_sleep_avg_hours", "recent sleep average (hours)"),
    ]:
        if data[key] is not None:
            values.append(f"{title}: {data[key]}")
    caveat = (
        " The history is incomplete."
        if data["missing_fraction"] > 0
        or data["missing_fields"]
        or data["sample_count"] == 0
        else ""
    )
    return f"{label}, seven-day summary: {'; '.join(values)}.{caveat} These summaries do not establish a cause or diagnosis."


def _finalize_once(state: AgentState, runtime: Runtime[RunDependencies]):
    ctx = runtime.context
    if state.get("terminal_reason"):
        return {"output": fallback(state, ctx, state["terminal_reason"])}
    try:
        last = state["messages"][-1]
        if (
            not isinstance(last, AIMessage)
            or last.tool_calls
            or not isinstance(last.content, str)
        ):
            raise ValueError("Missing final model response")
        draft = FinalDraft.model_validate_json(last.content)
        # Keep valid observed selections when the model repeats measurements in
        # its acknowledgement. Discard that whole free-form field; never attempt
        # to edit a diagnostic assertion into an apparently supported statement.
        discarded_reply = unsafe_draft(draft.reply)
        parts = [
            "I hear you. Here is the information available for your request."
            if discarded_reply
            else draft.reply
        ]
        sources = []
        seen = set()

        def add_source(item):
            ref = ctx.catalog.source_ref(item)
            if ref["chunk_id"] not in seen:
                sources.append(ref)
                seen.add(ref["chunk_id"])
            return next(
                i for i, s in enumerate(sources, 1) if s["chunk_id"] == ref["chunk_id"]
            )

        for citation in draft.citations:
            item = state["evidence"].get(citation.chunk_id)
            if item is None or citation.quote not in item["text"]:
                raise ValueError("Invented citation or unsupported quotation")
            if not relevant_overlap(ctx.request.message, citation.quote):
                continue
            n = add_source(item)
            parts.append(f"{item['publisher']} guidance [{n}]: “{citation.quote}”")
        for name in dict.fromkeys(draft.context_tools):
            if name not in ctx.permitted_tools or name not in state["context_results"]:
                raise ValueError("Unobserved or unauthorized context claim")
            parts.append(render_context(name, state["context_results"][name]))
        if draft.exercise_id:
            exercise = state["exercises"].get(draft.exercise_id)
            if not exercise:
                raise ValueError("Unretrieved exercise")
            item = state["evidence"][exercise["chunk_id"]]
            n = add_source(item)
            parts.append(
                f"If you would like, you can choose this optional activity: {exercise['title']} [{n}]. "
                + " ".join(
                    f"{i}. {step}" for i, step in enumerate(exercise["steps"], 1)
                )
                + " You can stop or choose something else if it does not feel helpful."
            )
        if not sources and any(
            t["name"] == "search_guidance" for t in state["tool_trace"]
        ):
            parts.append(
                "I couldn't select verified evidence to support specific guidance for this request."
            )
        if any(t["status"] != "ok" for t in state["tool_trace"]):
            parts.append(
                "Some requested information could not be obtained, so I have not filled in the gaps."
            )
        if discarded_reply and not (
            sources or draft.context_tools or draft.exercise_id
        ):
            raise ValueError(
                "No verified content remains after discarding acknowledgement"
            )
        reply = "\n\n".join(parts)
        if ctx.model.is_mock:
            reply = "[Mock model demonstration] " + reply
        return {
            "acknowledgement_replaced": discarded_reply,
            "output": {
                "reply": reply,
                "sources": sources,
                "tool_trace": state["tool_trace"],
                "simulated_data_used": state["simulated_data_used"],
            },
        }
    except (ValueError, KeyError, TypeError):
        return {
            "terminal_reason": "final_validation_failed",
            "output": fallback(state, ctx, "final_validation_failed"),
        }


async def finalize(state: AgentState, runtime: Runtime[RunDependencies]):
    result = _finalize_once(state, runtime)
    ctx = runtime.context
    if (
        state.get("terminal_reason")
        or result.get("terminal_reason") != "final_validation_failed"
        or not hasattr(ctx.model, "afinalize")
    ):
        return result
    # Repair only the final selection once. Never execute additional tools, retry
    # failed provider calls, or relax evidence/permission validation to make it pass.
    updates = {"model_calls": state["model_calls"] + 1, "finalization_repairs": 1}
    instruction = (
        SYSTEM_PROMPT
        + "\nFinal selection only: no more tool calls are possible. Return the required JSON from the observed results. Put only a brief empathetic acknowledgement or clarification in reply; no measurements, factual advice, exercise steps or tool claims. Choose physiological tools only in context_tools. A selected exercise belongs in exercise_id, never context_tools. If no suitable excerpt is available, use an empty citations list."
    )
    schema = FinalDraft.model_json_schema()
    observed_context = sorted(set(state["context_results"]) & ctx.permitted_tools)
    context_field = schema["properties"]["context_tools"]
    if observed_context:
        context_field["items"]["enum"] = observed_context
    else:
        context_field["maxItems"] = 0
    if state["evidence"]:
        schema["$defs"]["CitationSelection"]["properties"]["chunk_id"]["enum"] = sorted(
            state["evidence"]
        )
    else:
        schema["properties"]["citations"]["maxItems"] = 0
    schema["properties"]["exercise_id"] = (
        {"enum": [None, *sorted(state["exercises"])], "type": ["null", "string"]}
        if state["exercises"]
        else {"type": "null"}
    )
    instruction += (
        "\nOnly observed results may be selected. Available context results: "
        + (", ".join(observed_context) or "none")
        + ". Available exercise IDs: "
        + (", ".join(sorted(state["exercises"])) or "none")
        + ". Never put physiological results in citations. Copy exact source substrings without adding ellipses."
    )
    try:
        message = await asyncio.wait_for(
            ctx.model.afinalize(
                [SystemMessage(content=instruction), *state["messages"][:-1]],
                schema,
            ),
            ctx.model_timeout_seconds,
        )
        if (
            not isinstance(message, AIMessage)
            or message.tool_calls
            or message.invalid_tool_calls
        ):
            raise ValueError("Invalid final repair")
        repaired = {**state, "messages": [*state["messages"][:-1], message]}
        return {**_finalize_once(repaired, runtime), **updates, "messages": [message]}
    except ProviderError as exc:
        return {
            **updates,
            "terminal_reason": exc.code,
            "output": fallback(state, ctx, exc.code),
        }
    except asyncio.TimeoutError:
        return {
            **updates,
            "terminal_reason": "provider_timeout",
            "output": fallback(state, ctx, "provider_timeout"),
        }
    except Exception:
        return {**result, **updates}


def build_graph(checkpointer=None):
    graph = StateGraph(AgentState, context_schema=RunDependencies)
    graph.add_node("llm_agent", llm_agent)
    graph.add_node("tool_execution", tool_execution)
    graph.add_node("finalize", finalize)
    graph.add_edge(START, "llm_agent")
    graph.add_conditional_edges(
        "llm_agent",
        tool_decision,
        {"tool_execution": "tool_execution", "finalize": "finalize"},
    )
    graph.add_conditional_edges(
        "tool_execution",
        after_tools,
        {"llm_agent": "llm_agent", "finalize": "finalize"},
    )
    graph.add_edge("finalize", END)
    return graph.compile(checkpointer=checkpointer, name="mindsync-agent")
