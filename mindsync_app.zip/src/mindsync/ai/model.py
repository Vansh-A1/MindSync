"""Explicit Groq provider adapter and deterministic structured-tool-call mock."""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass, field
from contextvars import ContextVar
from urllib.parse import urlparse
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

MODEL_BACKEND = ContextVar("mindsync_model_backend", default="environment")


class ProviderError(RuntimeError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(
            code
        )  # Never echo keys, request bodies or provider exception text.


@dataclass(frozen=True)
class ModelSettings:
    mock: bool
    model: str
    base_url: str
    api_key: str = field(default="", repr=False)
    timeout_seconds: float = 30.0

    @classmethod
    def from_env(cls):
        value = os.environ.get("MOCK_LLM", "false").lower()
        if value not in {"true", "false"}:
            raise ProviderError("invalid_mock_setting")
        mock = value == "true"
        model = os.environ.get("LLM_MODEL", "").strip()
        base = os.environ.get("LLM_BASE_URL", "https://api.groq.com/openai/v1").rstrip(
            "/"
        )
        key = os.environ.get("LLM_API_KEY", "")
        if mock:
            return cls(True, "deterministic-tool-mock-v1", "local")
        if not model:
            raise ProviderError("missing_model_id")
        if not key:
            raise ProviderError("missing_api_key")
        parsed = urlparse(base)
        if (
            parsed.scheme != "https"
            or parsed.netloc != "api.groq.com"
            or parsed.path != "/openai/v1"
            or parsed.query
            or parsed.fragment
        ):
            raise ProviderError("unsupported_provider_endpoint")
        return cls(False, model, base, key)

    def public(self):
        return {
            "mock": self.mock,
            "provider": "deterministic_mock" if self.mock else "groq",
            "model": self.model,
            "base_url": self.base_url,
            "temperature": 0.0,
            "timeout_seconds": self.timeout_seconds,
            "generation_options": self.generation_options(),
        }

    def generation_options(self):
        # GPT-OSS documents include_reasoning (not reasoning_format). Explicit
        # low effort also avoids empty final responses observed in live checks.
        if self.model in {"openai/gpt-oss-20b", "openai/gpt-oss-120b"}:
            return {
                "reasoning_effort": "low",
                "model_kwargs": {"include_reasoning": False},
            }
        if self.model == "qwen/qwen3.8-27b":
            return {"reasoning_effort": "none", "reasoning_format": "hidden"}
        return {}


class GroqChatModel:
    is_mock = False

    def __init__(self, settings: ModelSettings, *, client=None):
        self.settings = settings
        if client is None:
            from langchain_groq import ChatGroq

            client = ChatGroq(
                api_key=settings.api_key,
                model=settings.model,
                # Groq's SDK appends /openai/v1 itself. Keep the public compatible
                # API URL in settings, but give this native adapter only its origin.
                base_url=settings.base_url.removesuffix("/openai/v1"),
                temperature=0.0,
                timeout=settings.timeout_seconds,
                max_retries=0,
                max_tokens=1600,
                **settings.generation_options(),
            )
        self.client = client

    @property
    def configuration(self):
        return self.settings.public()

    async def ainvoke(self, messages, tools):
        runnable = (
            self.client.bind_tools(list(tools), tool_choice="auto")
            if tools
            else self.client
        )
        return await self._invoke(runnable, messages)

    async def afinalize(self, messages, schema):
        """Structured selection (guided generation or repair), without tool binding."""

        def strict_schema(value):
            if isinstance(value, list):
                return [strict_schema(item) for item in value]
            if not isinstance(value, dict):
                return value
            result = {
                key: strict_schema(item)
                for key, item in value.items()
                if key != "default"
            }
            if result.get("type") == "object":
                result["required"] = list(result.get("properties", {}))
                result["additionalProperties"] = False
            return result

        if self.settings.model not in {
            "openai/gpt-oss-20b",
            "openai/gpt-oss-120b",
            "qwen/qwen3.8-27b",
        }:
            raise ProviderError("final_format_repair_unsupported")
        runnable = self.client.bind(
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "agent_final_selection",
                    "strict": True,
                    "schema": strict_schema(schema),
                },
            }
        )
        return await self._invoke(runnable, messages)

    async def _invoke(self, runnable, messages):
        try:
            result = await asyncio.wait_for(
                runnable.ainvoke(messages, config={"callbacks": []}),
                self.settings.timeout_seconds,
            )
            if not isinstance(result, AIMessage):
                raise ProviderError("unsupported_model_response")
            content = result.content
            if isinstance(content, list):
                content = "".join(
                    item.get("text", "")
                    for item in content
                    if isinstance(item, dict) and item.get("type") == "text"
                )
            # Do not checkpoint or expose provider reasoning/opaque response metadata.
            return AIMessage(
                content=content,
                tool_calls=result.tool_calls,
                invalid_tool_calls=result.invalid_tool_calls,
                usage_metadata=result.usage_metadata,
            )
        except ProviderError:
            raise
        except (asyncio.TimeoutError, TimeoutError) as exc:
            raise ProviderError("provider_timeout") from exc
        except Exception as exc:
            status = getattr(exc, "status_code", None)
            body = getattr(exc, "body", {})
            if isinstance(body, dict):
                body = body.get("error", body)
            if isinstance(body, dict) and body.get("code") == "tool_use_failed":
                code = "invalid_tool_generation"
            elif isinstance(body, dict) and body.get("code") == "json_validate_failed":
                code = "invalid_structured_generation"
            elif status in (401, 403):
                code = "authentication_failed"
            elif status == 429:
                code = "rate_limited"
            elif status in (400, 404, 422):
                code = "model_or_tool_schema_rejected"
            elif type(exc).__name__ in {
                "APITimeoutError",
                "ReadTimeout",
                "ConnectTimeout",
            }:
                code = "provider_timeout"
            elif type(exc).__name__ in {
                "APIConnectionError",
                "ConnectError",
                "NetworkError",
            }:
                code = "network_failure"
            else:
                code = "provider_failure"
            raise ProviderError(code) from exc


def exact_excerpt(text: str) -> str:
    # Exact substring, no paraphrased claim dressed as a verified quotation.
    end = re.search(r"[.!?](?:\s|$)", text)
    if end and end.end() <= 500:
        return text[: end.start() + 1]
    return text[:480].rsplit(" ", 1)[0]


class MockChatModel:
    """Fixture-driven behavior, not an LLM. It issues real AIMessage.tool_calls."""

    is_mock = True
    configuration = {
        "mock": True,
        "provider": "deterministic_mock",
        "model": "deterministic-tool-mock-v1",
        "temperature": 0.0,
    }

    async def ainvoke(self, messages, tools):
        last_user = max(
            i for i, m in enumerate(messages) if isinstance(m, HumanMessage)
        )
        query = str(messages[last_user].content)
        results = {
            m.name: json.loads(m.content)
            for m in messages[last_user + 1 :]
            if isinstance(m, ToolMessage)
        }
        allowed = {t.name for t in tools}
        if not results:
            low = query.lower()
            planned = []
            exercise = (
                "grounding"
                if "grounding" in low
                else (
                    "mindful_attention"
                    if "mindful" in low
                    else ("worry_reflection" if "worry exercise" in low else None)
                )
            )
            wellbeing = bool(
                re.search(
                    r"stress|worr|sleep|upset|distress|pulse|heart|grounding|mindful|exam",
                    low,
                )
            )
            if wellbeing and "search_guidance" in allowed:
                planned.append(("search_guidance", {"query": query}))
            if exercise and "get_support_exercise" in allowed:
                planned.append(("get_support_exercise", {"exercise_type": exercise}))
            context_relevant = wellbeing and exercise is None
            if context_relevant and "get_current_vitals" in allowed:
                planned.append(("get_current_vitals", {}))
            if (
                context_relevant
                and re.search(r"sleep|recent|history|week|exam|missing|stale", low)
                and "analyze_vitals_history" in allowed
            ):
                planned.append(("analyze_vitals_history", {}))
            if planned:
                return AIMessage(
                    content="",
                    tool_calls=[
                        {
                            "name": name,
                            "args": args,
                            "id": f"mock_call_{i}",
                            "type": "tool_call",
                        }
                        for i, (name, args) in enumerate(planned)
                    ],
                )
        passages = (
            results.get("search_guidance", {}).get("data", {}).get("passages", [])
        )
        citations = [
            {"chunk_id": p["chunk_id"], "quote": exact_excerpt(p["text"])}
            for p in passages[:2]
        ]
        contexts = [
            name
            for name in ("get_current_vitals", "analyze_vitals_history")
            if results.get(name, {}).get("ok")
        ]
        exercise = results.get("get_support_exercise", {}).get("data", {}).get("id")
        reply = (
            "That sounds difficult. What part of this would you most like support with?"
        )
        if not results:
            reply = "I'm here to listen. What would you like help with?"
        return AIMessage(
            content=json.dumps(
                {
                    "reply": reply,
                    "citations": citations,
                    "context_tools": contexts,
                    "exercise_id": exercise,
                }
            )
        )


class ScriptedModel:
    """Adversarial offline fixture: messages or failures, with observable inputs."""

    is_mock = True
    configuration = {
        "mock": True,
        "provider": "scripted_test_fixture",
        "model": "scripted-v1",
    }

    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def ainvoke(self, messages, tools):
        self.calls.append(
            {"messages": list(messages), "tool_names": [t.name for t in tools]}
        )
        if not self.responses:
            raise ProviderError("script_exhausted")
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


class GuidedMockModel(MockChatModel):
    """Explicit offline selection fixture; never used as a live-model fallback."""

    configuration = {**MockChatModel.configuration, "model": "guided-selection-mock-v1"}

    async def afinalize(self, messages, schema):
        from .graph import relevant_overlap

        packet = json.loads(messages[-1].content)
        citations = []
        for chunk_id, item in packet["evidence"].items():
            for sentence in item["sentences"]:
                if len(sentence["text"]) <= 1200 and relevant_overlap(
                    packet["user_message"], sentence["text"]
                ):
                    citations.append(
                        {
                            "chunk_id": chunk_id,
                            "sentence_start": sentence["number"],
                            "sentence_end": sentence["number"],
                        }
                    )
                    break
            if citations:
                break
        return AIMessage(
            content=json.dumps(
                {
                    "opening": "support",
                    "citations": citations,
                    "context_tools": list(packet["context"]),
                    "exercise_id": next(iter(packet["exercises"]), None),
                    "closing": "choose_next" if citations else "clarify",
                }
            )
        )


class LocalGuidanceModel(GuidedMockModel):
    """Explicit deterministic selection over the frozen corpus, with no LLM call."""

    is_mock = False
    configuration = {
        "mock": False,
        "provider": "local_deterministic",
        "model": "extractive-selector-v2",
        "external_llm": False,
    }

    async def afinalize(self, messages, schema):
        packet = json.loads(messages[-1].content)
        # Select response excerpts only; retrieval order/scores/corpus stay frozen.
        # The original first-match fixture preferred generic opening sentences.
        ignored = set(
            "the and this that with have what how can could should would about feel feeling help please want some when where which like doing from your does there even though are was for has not but all our just look".split()
        )

        def terms(text):
            return {
                word[:5]
                for word in re.findall(r"[a-z]{3,}", text.lower())
                if word not in ignored
            }

        query_terms = terms(packet["user_message"])
        candidates = []
        for chunk_id, item in packet["evidence"].items():
            for span in item["selectable_ranges"]:
                first, last = span["sentence_start"], span["sentence_end"]
                text = " ".join(
                    s["text"] for s in item["sentences"] if first <= s["number"] <= last
                )
                overlap = len(query_terms & terms(text))
                if overlap:
                    candidates.append(
                        (
                            overlap,
                            -(last - first),
                            -len(text),
                            {"chunk_id": chunk_id, **span},
                        )
                    )
        citations = [max(candidates, key=lambda x: x[:3])[3]] if candidates else []
        return AIMessage(
            content=json.dumps(
                {
                    "opening": "support",
                    "citations": citations,
                    "context_tools": list(packet["context"]),
                    "exercise_id": next(iter(packet["exercises"]), None),
                    "closing": "choose_next" if citations else "clarify",
                }
            )
        )


def create_model(settings: ModelSettings | None = None, *, workflow=None):
    backend = MODEL_BACKEND.get()
    if backend == "local":
        return LocalGuidanceModel()
    settings = settings or ModelSettings.from_env()
    if backend == "live" and settings.mock:
        raise ProviderError("live_backend_requires_mock_false")
    workflow = workflow or os.environ.get("AGENT_WORKFLOW", "autonomous")
    if settings.mock and workflow == "guided":
        return GuidedMockModel()
    return MockChatModel() if settings.mock else GroqChatModel(settings)
