"""Internal graph state and request-scoped dependencies, not shared contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Annotated, Any, Callable
from typing_extensions import TypedDict
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages


class AgentState(TypedDict, total=False):
    messages: Annotated[list[AnyMessage], add_messages]
    tool_call_count: int
    tool_rounds: int
    evidence: dict[str, dict]
    tool_trace: list[dict]
    context_results: dict[str, dict]
    exercises: dict[str, dict]
    simulated_data_used: bool
    terminal_reason: str | None
    output: dict
    model_calls: int
    finalization_repairs: int
    acknowledgement_replaced: bool
    guided_results: dict[str, dict]
    guided_evidence: dict[str, dict]
    rag_evidence_ids: list[str]
    rag_fingerprint: str | None
    generation_outcome: str
    validation_error: str | None
    rejected_selections: list[dict]
    generation_attempts: list[dict]


@dataclass(frozen=True)
class RunDependencies:
    request: Any  # Actual ChatRequest in production; plain fixture objects only in standalone tests.
    context_provider: Any
    model: Any
    tools: dict[str, Any]
    catalog: Any
    permitted_tools: frozenset[str]
    run_id: str
    now: Callable[[], datetime] = field(default=lambda: datetime.now(timezone.utc))
    tool_timeout_seconds: float = 10.0
    model_timeout_seconds: float = 30.0
    max_tool_calls: int = 4
    max_tool_rounds: int = 3
