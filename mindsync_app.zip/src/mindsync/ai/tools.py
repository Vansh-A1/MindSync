"""Validated, request-bound agent tools around the frozen RAG and context services."""

from __future__ import annotations

import asyncio
import inspect
import math
from contextvars import ContextVar
from collections.abc import Mapping
from datetime import datetime, timezone, timedelta
from typing import Literal

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, ConfigDict, Field, field_validator

from mindsync.rag.ingest import KNOWLEDGE_DIR, load_passages
from mindsync.rag.sources import load_sources, validate_passage
from mindsync.rag.retrieval import search_guidance as rag_search_guidance
from mindsync.rag.schemas import Passage
from mindsync.activities.exercises import get_support_exercise as approved_exercise
from mindsync.config import Settings

BASE_TOOLS = frozenset({"search_guidance", "get_support_exercise"})
FRESHNESS_MINUTES = ContextVar("mindsync_freshness_minutes", default=None)
MODES = {
    "text_only": BASE_TOOLS,
    "current_vitals": BASE_TOOLS | {"get_current_vitals"},
    "full_context": BASE_TOOLS | {"get_current_vitals", "analyze_vitals_history"},
}


class ToolDataError(ValueError):
    pass


class EmptyArgs(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SearchArgs(EmptyArgs):
    query: str = Field(min_length=1, max_length=4096, strict=True)

    @field_validator("query")
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError("Query must not be empty")
        return value.strip()


class ExerciseArgs(EmptyArgs):
    exercise_type: Literal["grounding", "mindful_attention", "worry_reflection"]


def mode_value(request) -> str:
    return getattr(request.mode, "value", request.mode)


def permitted_tools(request) -> frozenset[str]:
    mode = mode_value(request)
    if mode not in MODES:
        raise ValueError("Unsupported experiment mode")
    if type(request.consent_to_use_vitals) is not bool:
        raise ValueError("Consent must be explicit boolean")
    return frozenset(MODES[mode] if request.consent_to_use_vitals else BASE_TOOLS)


class EvidenceCatalog:
    """Exact identity validation against unchanged verified source/passages files."""

    def __init__(self):
        self.sources = load_sources(KNOWLEDGE_DIR / "sources.json")
        self.passages = {
            p.chunk_id: p
            for p in load_passages(KNOWLEDGE_DIR / "passages.jsonl", self.sources)
        }

    def validate(self, value) -> dict:
        data = (
            value.model_dump(mode="json")
            if hasattr(value, "model_dump")
            else dict(value)
        )
        passage = Passage.model_validate({k: data[k] for k in Passage.model_fields})
        validate_passage(passage, self.sources)
        if passage != self.passages.get(passage.chunk_id):
            raise ToolDataError("Evidence does not match verified corpus")
        # Source URL comes from the canonical registry, never from model output.
        if passage.url != self.sources[passage.source_id].url:
            raise ToolDataError("Evidence URL differs from source registry")
        result = passage.model_dump(mode="json")
        if "score" in data:
            if not isinstance(data["score"], (int, float)) or not math.isfinite(
                data["score"]
            ):
                raise ToolDataError("Invalid retrieval score")
            result["score"] = float(data["score"])
        return result

    def source_ref(self, value: dict) -> dict:
        validated = self.validate(value)
        return {
            k: validated[k]
            for k in ("source_id", "chunk_id", "publisher", "title", "url", "section")
        }


def as_data(value) -> dict:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="python")
    if isinstance(value, Mapping):
        return dict(value)
    raise ToolDataError(
        "Context service must return a shared model or structured mapping"
    )


def number(value, *, low: float, high: float, zero_allowed: bool = True):
    if value is None:
        return None
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
    ):
        raise ToolDataError("Invalid numeric context value")
    if not low <= value <= high or not zero_allowed and value == 0:
        raise ToolDataError("Context value outside data validation bounds")
    return value


def validate_current(value, profile_id: str, now: datetime) -> dict:
    if value is None:
        return {"available": False, "reason": "No current reading is available."}
    d = as_data(value)
    if d.get("profile_id") != profile_id:
        raise ToolDataError("Context profile mismatch")
    if type(d.get("simulated")) is not bool:
        raise ToolDataError("Missing simulation flag")
    measured = d.get("measured_at")
    if isinstance(measured, str):
        try:
            measured = datetime.fromisoformat(measured.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ToolDataError("Invalid measurement timestamp") from exc
    if not isinstance(measured, datetime) or measured.utcoffset() is None:
        raise ToolDataError("Measurement timestamp must include a timezone")
    if measured > now + timedelta(minutes=5):
        raise ToolDataError("Measurement timestamp is in the future")
    # Shared contract v1 defines activity as a normalized numeric value.
    activity = number(d.get("activity_level"), low=0, high=1)
    result = {
        "available": True,
        "measured_at": measured.isoformat(),
        "data_stale": now - measured
        > timedelta(
            minutes=FRESHNESS_MINUTES.get() or Settings.from_env().stale_after_minutes
        ),
        "heart_rate_bpm": number(d.get("heart_rate_bpm"), low=20, high=250),
        "spo2_percent": number(d.get("spo2_percent"), low=50, high=100),
        "respiratory_rate_per_min": number(
            d.get("respiratory_rate_per_min"), low=3, high=80
        ),
        "activity_level": activity,
        "simulated": d["simulated"],
    }
    result["missing_fields"] = [
        k
        for k in (
            "heart_rate_bpm",
            "spo2_percent",
            "respiratory_rate_per_min",
            "activity_level",
        )
        if result[k] is None
    ]
    return result


def validate_history(value, profile_id: str) -> dict:
    if value is None:
        return {"available": False, "reason": "No history summary is available."}
    d = as_data(value)
    if d.get("profile_id") != profile_id:
        raise ToolDataError("Context profile mismatch")
    if d.get("window_days") != 7:
        raise ToolDataError("History must cover the requested seven-day window")
    if type(d.get("sample_count")) is not int or not 0 <= d["sample_count"] <= 10000000:
        raise ToolDataError("Invalid history sample count")
    if any(type(d.get(k)) is not bool for k in ("data_stale", "simulated")):
        raise ToolDataError("Missing history quality/simulation flags")
    missing = number(d.get("missing_fraction"), low=0, high=1)
    if missing is None:
        raise ToolDataError("Missing data completeness information")
    result = {
        "available": True,
        "window_days": 7,
        "sample_count": d["sample_count"],
        "missing_fraction": missing,
        "data_stale": d["data_stale"],
        "simulated": d["simulated"],
        "mean_heart_rate_bpm": number(
            d.get("mean_heart_rate_bpm"), low=0, high=300, zero_allowed=False
        ),
        "earlier_sleep_avg_hours": number(
            d.get("earlier_sleep_avg_hours"), low=0, high=24
        ),
        "recent_sleep_avg_hours": number(
            d.get("recent_sleep_avg_hours"), low=0, high=24
        ),
    }
    if result["sample_count"] == 0:
        for key in (
            "mean_heart_rate_bpm",
            "earlier_sleep_avg_hours",
            "recent_sleep_avg_hours",
        ):
            result[key] = None
    result["missing_fields"] = [
        k
        for k in (
            "mean_heart_rate_bpm",
            "earlier_sleep_avg_hours",
            "recent_sleep_avg_hours",
        )
        if result[k] is None
    ]
    return result


async def call_provider(fn, *args, **kwargs):
    result = (
        await fn(*args, **kwargs)
        if inspect.iscoroutinefunction(fn)
        else await asyncio.to_thread(fn, *args, **kwargs)
    )
    return await result if inspect.isawaitable(result) else result


def build_tools(
    request, context_provider, catalog: EvidenceCatalog, *, lookup=None, now=None
) -> dict[str, StructuredTool]:
    lookup = lookup or rag_search_guidance
    clock = now or (lambda: datetime.now(timezone.utc))
    allowed = permitted_tools(request)

    async def search_guidance(query: str):
        # The frozen public function is called exactly with top_k=4.
        hits = await asyncio.to_thread(lookup, query, top_k=4)
        if not isinstance(hits, list) or len(hits) > 4:
            raise ToolDataError("Invalid RAG result envelope")
        evidence = [catalog.validate(hit) for hit in hits]
        unique = {p["chunk_id"]: p for p in evidence}
        return {
            "data": {"passages": list(unique.values())},
            "evidence": list(unique.values()),
            "simulated": False,
            "summary": f"Retrieved {len(unique)} verified passages; permitted.",
        }

    async def get_current_vitals():
        if "get_current_vitals" not in allowed:
            raise PermissionError("Vitals not authorized")
        value = await call_provider(
            context_provider.get_current_vitals, request.profile_id
        )
        data = validate_current(value, request.profile_id, clock())
        return {
            "data": data,
            "evidence": [],
            "simulated": data.get("simulated", False),
            "summary": f"Current context {'available' if data['available'] else 'missing'}; permitted; simulated={data.get('simulated', False)}; stale={data.get('data_stale', False)}.",
        }

    async def analyze_vitals_history():
        if "analyze_vitals_history" not in allowed:
            raise PermissionError("History not authorized")
        value = await call_provider(
            context_provider.get_history_summary, request.profile_id, days=7
        )
        data = validate_history(value, request.profile_id)
        return {
            "data": data,
            "evidence": [],
            "simulated": data.get("simulated", False),
            "summary": f"Seven-day context {'available' if data['available'] else 'missing'}; permitted; simulated={data.get('simulated', False)}; stale={data.get('data_stale', False)}.",
        }

    async def get_support_exercise(exercise_type: str):
        result = approved_exercise(exercise_type, catalog=catalog)
        evidence = catalog.validate(result.pop("evidence"))
        # Approved steps are adaptations, not verbatim quotations. Supply the
        # original passage separately so the model can cite exact source text.
        result["source_passage"] = evidence["text"]
        return {
            "data": result,
            "evidence": [evidence],
            "simulated": False,
            "summary": f"Loaded approved optional exercise {exercise_type}; permitted.",
        }

    definitions = [
        (
            "search_guidance",
            search_guidance,
            SearchArgs,
            "Find verified wellbeing guidance; returns complete passages and source IDs. No diagnosis.",
        ),
        (
            "get_support_exercise",
            get_support_exercise,
            ExerciseArgs,
            "Get an approved optional coping activity and verified source.",
        ),
        (
            "get_current_vitals",
            get_current_vitals,
            EmptyArgs,
            "Read authorized current physiological data for the trusted request profile; no arguments, no diagnosis.",
        ),
        (
            "analyze_vitals_history",
            analyze_vitals_history,
            EmptyArgs,
            "Read the authorized seven-day statistical summary for the trusted profile; no arguments.",
        ),
    ]
    return {
        name: StructuredTool.from_function(
            coroutine=fn, name=name, args_schema=schema, description=description
        )
        for name, fn, schema, description in definitions
        if name in allowed
    }
