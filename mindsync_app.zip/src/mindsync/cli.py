"""Reproducible local setup and launch, with no credential persistence."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time


class SetupError(RuntimeError):
    """Local, deliberately user-readable setup diagnostics; never provider text."""


def validate_ports(api_port, ui_port=None):
    ports = [api_port] if ui_port is None else [api_port, ui_port]
    if len(set(ports)) != len(ports):
        raise SetupError("API and dashboard ports must be different.")
    for port in ports:
        if not 1 <= port <= 65535:
            raise SetupError("Ports must be between 1 and 65535.")
        try:
            with socket.socket() as sock:
                # Match the servers' restart semantics: a closed connection in
                # TIME_WAIT is not an active owner, but a listening socket is.
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", port))
                sock.listen(1)
        except OSError:
            raise SetupError(
                f"Local port {port} is unavailable. Choose another port or stop its owner."
            ) from None


def resource_files():
    bundled = Path(__file__).with_name("resources")
    if bundled.is_dir():
        return bundled, [p for p in bundled.rglob("*") if p.is_file()]
    root = Path(__file__).resolve().parents[2]
    files = [
        *root.glob("data/knowledge/*"),
        *root.glob("frontend/*.py"),
        *root.glob("frontend/*.css"),
        root / ".streamlit/config.toml",
        root / "evaluation/results/rag_results.json",
        root / "evaluation/agent_cases.json",
        root / "evaluation/phase3_live_results/public_live_qwen/agent_evaluation.json",
        *root.glob("evaluation/phase4_results/live_*/agent_evaluation.json"),
        root / "evaluation/integration/live_oss20_final/agent_evaluation.json",
    ]
    return root, [p for p in files if p.is_file()]


def materialize(home):
    root, files = resource_files()
    if not files:
        raise SetupError(
            "Distribution resources are missing; reinstall the built wheel"
        )
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Check all collisions before writing. Setup never replaces local edits.
    for source in files:
        target = home / source.relative_to(root)
        if target.exists() and target.read_bytes() != source.read_bytes():
            raise SetupError(
                f"Existing resource differs: {target}. Preserve it and choose a new MINDSYNC_HOME."
            )
    for source in files:
        target = home / source.relative_to(root)
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            shutil.copy2(source, target)
    return len(files)


def setup_home(home, download):
    count = materialize(home)
    from .rag.index import MiniLMEncoder, build_index
    from .storage.migrations import migrate
    from .simulator.seed import seed
    from .config import Settings

    encoder = MiniLMEncoder(device="cpu", local_files_only=not download)
    build_index(home / "data/knowledge", home / "runtime/rag_index", encoder)
    # Cached model validation still happens if an existing index is reused.
    encoder.encode(["local setup verification"])
    migrate(Settings.from_env().db_path)
    seed(Settings.from_env().db_path)
    print(
        json.dumps(
            {
                "home": str(home),
                "resources": count,
                "index": "ready",
                "database": "ready",
                "model_download_authorized": download,
            },
            indent=2,
        )
    )


def doctor(home):
    from .rag.retrieval import search_guidance

    result = {
        "home": str(home),
        "llm_model_configured": bool(os.getenv("LLM_MODEL")),
        "llm_key_configured": bool(os.getenv("LLM_API_KEY")),
        "live_provider_tested": False,
    }
    try:
        start = time.perf_counter()
        passages = search_guidance("support with stress", top_k=4)
        result.update(
            rag_ready=True,
            evidence_ids=[p.chunk_id for p in passages],
            retrieval_ms=round((time.perf_counter() - start) * 1000, 1),
        )
    except Exception as exc:
        result.update(
            rag_ready=False,
            error=type(exc).__name__,
            recovery="Run mindsync setup; first use may require --download-model",
        )
    print(json.dumps(result, indent=2))
    return 0 if result["rag_ready"] else 1


def launch(home, args):
    if not (home / "frontend/app.py").is_file():
        raise SetupError("Dashboard resources missing; run mindsync setup")
    validate_ports(args.port, None if args.no_ui else args.ui_port)
    env = {
        **os.environ,
        "MINDSYNC_HOME": str(home),
        "MINDSYNC_AGENT": args.backend,
        "AGENT_WORKFLOW": args.workflow,
        "MINDSYNC_API_URL": f"http://127.0.0.1:{args.port}",
        "HF_HUB_OFFLINE": "1",
        "LANGSMITH_TRACING": "false",
    }
    children = []
    try:
        children.append(
            subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "mindsync.platform.api:app",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(args.port),
                    "--no-access-log",
                ],
                cwd=home,
                env=env,
            )
        )
        import httpx

        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            if children[0].poll() is not None:
                raise RuntimeError(
                    "API failed to start; check that the port is available"
                )
            try:
                if (
                    httpx.get(
                        env["MINDSYNC_API_URL"] + "/health", timeout=1
                    ).status_code
                    == 200
                ):
                    break
            except httpx.HTTPError:
                pass
            time.sleep(0.2)
        else:
            raise RuntimeError("API did not become ready within 25 seconds")
        if not args.no_ui:
            children.append(
                subprocess.Popen(
                    [
                        sys.executable,
                        "-m",
                        "streamlit",
                        "run",
                        str(home / "frontend/app.py"),
                        "--server.port",
                        str(args.ui_port),
                        "--server.address",
                        "127.0.0.1",
                        "--browser.gatherUsageStats=false",
                        "--server.fileWatcherType",
                        "none",
                    ],
                    cwd=home,
                    env=env,
                )
            )
        if args.publish:
            children.append(
                subprocess.Popen(
                    [
                        sys.executable,
                        "-m",
                        "mindsync.simulator.publisher",
                        "--url",
                        env["MINDSYNC_API_URL"],
                    ],
                    cwd=home,
                    env=env,
                )
            )
        target_port = args.port if args.no_ui else args.ui_port
        effective_workflow = "guided" if args.backend == "local" else args.workflow
        print(
            f"MindSync {args.backend}/{effective_workflow}: http://127.0.0.1:{target_port} · Ctrl+C stops this run",
            flush=True,
        )
        while all(p.poll() is None for p in children):
            time.sleep(0.5)
        raise RuntimeError("A demo process stopped; inspect its error above")
    except KeyboardInterrupt:
        return 0
    finally:
        for process in reversed(children):
            if process.poll() is None:
                process.terminate()
        for process in children:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--home",
        type=Path,
        help="Local data/configuration directory (or MINDSYNC_HOME)",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    setup = commands.add_parser(
        "setup",
        help="Materialize verified resources, build/reuse index and seed fictional data",
    )
    setup.add_argument(
        "--download-model",
        action="store_true",
        help="Allow initial pinned MiniLM download from Hugging Face",
    )
    commands.add_parser(
        "doctor", help="Verify actual local retrieval; does not call the LLM"
    )
    run = commands.add_parser("run", help="Start the local application")
    run.add_argument("--backend", choices=["local", "live", "mock"], default="local")
    run.add_argument("--workflow", choices=["guided", "autonomous"], default="guided")
    run.add_argument("--port", type=int, default=8000)
    run.add_argument("--ui-port", type=int, default=8501)
    run.add_argument(
        "--publish", action="store_true", help="Run the synthetic telemetry publisher"
    )
    run.add_argument("--no-ui", action="store_true")
    args = parser.parse_args(argv)
    if args.home:
        os.environ["MINDSYNC_HOME"] = str(args.home.expanduser().resolve())
    from .paths import PROJECT_ROOT

    try:
        if args.command == "setup":
            setup_home(PROJECT_ROOT, args.download_model)
            return 0
        if args.command == "doctor":
            return doctor(PROJECT_ROOT)
        return launch(PROJECT_ROOT, args)
    except SetupError as exc:
        print(f"MindSync {args.command}: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        # Never expose arbitrary provider exception bodies or environment secrets.
        print(
            f"MindSync {args.command} failed: {type(exc).__name__}. Check setup, local paths and process logs.",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
