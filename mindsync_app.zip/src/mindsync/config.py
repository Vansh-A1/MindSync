import os
from dataclasses import dataclass
from pathlib import Path
from .paths import PROJECT_ROOT


@dataclass(frozen=True)
class Settings:
    db_path: Path = PROJECT_ROOT / "runtime/mindsync.db"
    agent: str = "local"
    seed_demo: bool = True
    stale_after_minutes: int = 120
    agent_timeout_seconds: float = 45
    workflow: str = "guided"

    def __post_init__(self):
        if self.agent not in {"live", "local", "mock", "real"}:
            raise ValueError(
                "MINDSYNC_AGENT must be live, local or mock (real is a deprecated alias for live)"
            )
        if self.workflow not in {"guided", "autonomous"}:
            raise ValueError("AGENT_WORKFLOW must be guided or autonomous")
        if (
            not 0 < self.stale_after_minutes <= 1440
            or not 0 < self.agent_timeout_seconds <= 180
        ):
            raise ValueError(
                "Freshness and request timeout must be positive and bounded"
            )

    @classmethod
    def from_env(cls):
        return cls(
            db_path=Path(
                os.getenv("MINDSYNC_DB_PATH", str(PROJECT_ROOT / "runtime/mindsync.db"))
            ),
            agent=os.getenv("MINDSYNC_AGENT", "local"),
            seed_demo=os.getenv("MINDSYNC_SEED_DEMO", "true").lower() == "true",
            stale_after_minutes=int(os.getenv("MINDSYNC_STALE_MINUTES", "120")),
            agent_timeout_seconds=float(os.getenv("MINDSYNC_REQUEST_TIMEOUT", "45")),
            workflow=os.getenv("AGENT_WORKFLOW", "guided"),
        )
