"""Reproducible offline behavioral evaluation."""
