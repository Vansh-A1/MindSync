"""Filesystem layout shared by source checkouts and installed distributions.

No directory creation or network activity occurs during import. Installed users
run ``mindsync setup`` to materialize the bundled, unchanged knowledge resources.
"""

import os
from pathlib import Path

_checkout = Path(__file__).resolve().parents[2]
PROJECT_ROOT = (
    Path(os.environ["MINDSYNC_HOME"]).expanduser().resolve()
    if os.environ.get("MINDSYNC_HOME")
    else _checkout
    if (_checkout / "pyproject.toml").is_file()
    and (_checkout / "data/knowledge/sources.json").is_file()
    else Path.home() / ".local/share/mindsync"
)
KNOWLEDGE_DIR = PROJECT_ROOT / "data/knowledge"
