from contextlib import asynccontextmanager
from fastapi import FastAPI
from mindsync.config import Settings
from mindsync.storage.migrations import migrate
from mindsync.storage.repository import Repository
from mindsync.simulator.seed import seed
from .context_service import SQLiteContextProvider
from .routes import router
from .backends import canonical_backend, invoke
from .evidence import router as evidence_router


def create_app(settings=None, agent=None):
    settings = settings or Settings.from_env()
    backend = canonical_backend(settings.agent)
    injected_agent = agent
    if agent is None:

        async def agent(request, provider):
            return await invoke(request, provider, backend, settings.workflow)

    @asynccontextmanager
    async def lifespan(app):
        migrate(settings.db_path)
        if settings.seed_demo:
            seed(settings.db_path)
        # Readiness must not invoke the paid/remote provider or download models.
        from mindsync.rag.ingest import PROJECT_ROOT, KNOWLEDGE_DIR
        from mindsync.rag.index import MiniLMEncoder, load_index

        try:
            encoder = MiniLMEncoder(local_files_only=True)
            load_index(KNOWLEDGE_DIR, PROJECT_ROOT / "runtime/rag_index", encoder)
            model_dir = (
                encoder.cache_dir
                / "hub"
                / ("models--" + encoder.model_name.replace("/", "--"))
                / "snapshots"
                / encoder.model_revision
            )
            app.state.rag_ready = all(
                (model_dir / name).is_file()
                for name in ("model.safetensors", "tokenizer.json", "config.json")
            )
        except Exception:
            app.state.rag_ready = False
        yield

    app = FastAPI(
        title="MindSync AI — simulated wellbeing prototype", lifespan=lifespan
    )
    app.state.settings = settings
    app.state.repository = Repository(settings.db_path)
    app.state.context = SQLiteContextProvider(
        app.state.repository, settings.stale_after_minutes
    )
    app.state.agent = agent
    app.state.injected_agent = injected_agent is not None
    app.state.backend = backend
    app.state.rag_ready = False
    app.include_router(router)
    app.include_router(evidence_router)
    return app


app = create_app()
