"""Request-scoped backend choice; never mutate process env during a request."""

import os
from contextlib import contextmanager

from mindsync.ai.agent import WORKFLOW_OVERRIDE, run_agent
from mindsync.ai.model import MODEL_BACKEND, ModelSettings, ProviderError

LABELS = {
    "live": "Live Groq model + verified RAG",
    "local": "Local deterministic guidance + verified RAG (no LLM)",
    "mock": "Test mock (no grounded AI response)",
}


def canonical_backend(name):
    # The fork called deterministic guidance 'real'; that ambiguous name is
    # deprecated. Integration uses explicit local/live names and reports the alias.
    if name == "real":
        return "live"
    if name not in LABELS:
        raise ValueError("Unknown backend")
    return name


@contextmanager
def selected_backend(backend, workflow):
    backend_token = MODEL_BACKEND.set(backend)
    workflow_token = WORKFLOW_OVERRIDE.set("guided" if backend == "local" else workflow)
    try:
        yield
    finally:
        WORKFLOW_OVERRIDE.reset(workflow_token)
        MODEL_BACKEND.reset(backend_token)


async def invoke(request, provider, backend, workflow):
    backend = canonical_backend(backend)
    if backend == "mock":
        from .mock_agent import run_agent as mock_agent

        return await mock_agent(request, provider)
    with selected_backend(backend, workflow):
        output = await run_agent(request, provider)
    if backend == "local":
        output = output.model_copy(
            update={
                "reply": "[Local deterministic guidance — no language model]\n\n"
                + output.reply
            }
        )
    return output


def status(backend, rag_ready):
    configured = True
    reason = None
    if backend == "live":
        try:
            settings = ModelSettings.from_env()
            if settings.mock:
                raise ProviderError("live_backend_requires_mock_false")
        except ProviderError as exc:
            configured = False
            reason = f"Live configuration: {exc.code.replace('_', ' ')}. Check LLM_API_KEY, LLM_MODEL, the official Groq base URL and MOCK_LLM=false."
    ready = configured and (rag_ready or backend == "mock")
    if not rag_ready and backend != "mock":
        reason = "The local knowledge index needs setup or repair. See the setup guide."
    return {
        "id": backend,
        "label": LABELS[backend],
        "configured": configured,
        "ready": ready,
        "reason": reason,
        "live_provider_status": "not_verified_by_health_check"
        if backend == "live"
        else "not_applicable",
        "model": os.getenv("LLM_MODEL") if backend == "live" else None,
    }
