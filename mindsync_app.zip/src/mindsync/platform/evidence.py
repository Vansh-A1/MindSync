"""Read-only corpus and saved-evaluation views for the local demonstration."""

import asyncio
import json
from collections import Counter
from time import perf_counter

from fastapi import APIRouter, HTTPException, Query

from mindsync.rag.ingest import KNOWLEDGE_DIR, PROJECT_ROOT
from mindsync.rag.sources import load_sources
from mindsync.rag.retrieval import search_guidance

router = APIRouter()


@router.get("/evidence")
def evidence():
    try:
        sources = load_sources(KNOWLEDGE_DIR / "sources.json")
        passages = [
            json.loads(line)
            for line in (KNOWLEDGE_DIR / "passages.jsonl").read_text().splitlines()
            if line.strip()
        ]
    except Exception:
        raise HTTPException(
            503,
            "Verified knowledge files are unavailable; run the documented RAG setup",
        ) from None
    counts = Counter(p["source_id"] for p in passages)
    source_rows = [
        {**s.model_dump(mode="json"), "passage_count": counts[s.source_id]}
        for s in sources.values()
        if counts[s.source_id] > 0
    ]
    reports = []
    # Only named public synthetic evaluation artifacts; never accept a filesystem path.
    for label, relative in (
        ("Original retrieval benchmark", "evaluation/results/rag_results.json"),
        (
            "Phase 3 live autonomous",
            "evaluation/phase3_live_results/public_live_qwen/agent_evaluation.json",
        ),
        (
            "Phase 4 guided live v1",
            "evaluation/phase4_results/live_qwen_v1/agent_evaluation.json",
        ),
        (
            "Phase 4 guided live v2",
            "evaluation/phase4_results/live_qwen_v2/agent_evaluation.json",
        ),
        (
            "Phase 4 guided Qwen v3",
            "evaluation/phase4_results/live_qwen_v3/agent_evaluation.json",
        ),
        (
            "Guided GPT-OSS-20B, six scenarios",
            "evaluation/phase4_results/live_oss20_full/agent_evaluation.json",
        ),
        (
            "Guided GPT-OSS-20B, final repeat",
            "evaluation/integration/live_oss20_final/agent_evaluation.json",
        ),
    ):
        path = PROJECT_ROOT / relative
        if not path.is_file():
            continue
        data = json.loads(path.read_text())
        if "methods" in data:
            summary = {
                method: result["aggregate"]
                for method, result in data["methods"].items()
            }
        else:
            summary = data.get("summary") or {
                "runs": len(data.get("runs", [])),
                "selected_sources": sum(
                    bool(r["response"]["sources"]) for r in data.get("runs", [])
                ),
            }
        reports.append(
            {
                "label": label,
                "artifact": relative,
                "summary": summary,
                "model": data.get("model"),
                "human_review": "pending",
            }
        )
    return {
        "source_count": len(source_rows),
        "passage_count": len(passages),
        "sources": source_rows,
        "reports": reports,
        "scenarios": (
            [
                {key: case[key] for key in ("id", "message", "profile_id")}
                for case in json.loads(
                    (PROJECT_ROOT / "evaluation/agent_cases.json").read_text()
                )["cases"]
            ]
            if (PROJECT_ROOT / "evaluation/agent_cases.json").is_file()
            else []
        ),
        "default_retriever": "original hybrid",
        "clinical_validation": False,
    }


@router.get("/guidance")
async def guidance(query: str = Query(min_length=1, max_length=2000)):
    start = perf_counter()
    try:
        chunks = await asyncio.wait_for(
            asyncio.to_thread(search_guidance, query, top_k=4), timeout=15
        )
    except TimeoutError:
        raise HTTPException(
            504, "Retrieval took too long; warm the index and retry"
        ) from None
    except Exception:
        raise HTTPException(
            503, "Retrieval unavailable; check the local index and cached model"
        ) from None
    return {
        "query": query,
        "passages": [p.model_dump(mode="json") for p in chunks],
        "latency_ms": round((perf_counter() - start) * 1000, 1),
    }
