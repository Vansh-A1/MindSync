import asyncio
import logging
import hashlib
import json
from datetime import datetime, timedelta, timezone
from time import perf_counter
from fastapi import APIRouter, HTTPException, Request, Response
from typing import Literal
from pydantic import Field
from mindsync.contracts import (
    Contract,
    ChatRequest,
    ChatResponse,
    AgentOutput,
    Mode,
    VitalReading,
)
from .context_service import RestrictedContextProvider
from .safety import is_urgent, URGENT_REPLY
from .backends import invoke, status, LABELS
from mindsync.ai.agent import LAST_RUN_DIAGNOSTICS, RequestDiagnostics
from mindsync.ai.tools import FRESHNESS_MINUTES

router = APIRouter()
logger = logging.getLogger(__name__)


def require_profile(request, profile_id):
    if not request.app.state.repository.exists(profile_id):
        raise HTTPException(404, "Unknown synthetic profile")


@router.get("/health")
def health(request: Request):
    settings = request.app.state.settings
    return {
        "status": "ok",
        "agent": request.app.state.backend,
        "simulated": True,
        "workflow": settings.workflow,
        "rag_ready": request.app.state.rag_ready,
        "freshness_minutes": settings.stale_after_minutes,
        "request_timeout_seconds": settings.agent_timeout_seconds,
        "backends": [status(name, request.app.state.rag_ready) for name in LABELS],
        "deprecated_real_alias": settings.agent == "real",
    }


@router.get("/profiles")
def profiles(request: Request):
    return request.app.state.repository.profiles()


@router.get("/profiles/{profile_id}/vitals")
def vitals(profile_id: str, request: Request):
    require_profile(request, profile_id)
    now = datetime.now(timezone.utc)
    return {
        "current": request.app.state.context.get_current_vitals(profile_id),
        "history": request.app.state.repository.samples(
            profile_id, now - timedelta(days=7), now
        ),
        "summary": request.app.state.context.get_history_summary(profile_id),
        "sleep": request.app.state.repository.sleep(
            profile_id, (now - timedelta(days=7)).date(), now.date()
        ),
    }


@router.post("/telemetry", response_model=VitalReading)
def telemetry(reading: VitalReading, request: Request):
    require_profile(request, reading.profile_id)
    if not reading.simulated:
        raise HTTPException(422, "Only simulated measurements are accepted")
    if reading.measured_at > datetime.now(timezone.utc):
        raise HTTPException(422, "Future measurements are not accepted")
    return request.app.state.repository.save_vital(reading)


class CheckIn(Contract):
    mood: int = Field(ge=1, le=5, strict=True)
    note: str = Field(default="", max_length=2000)


@router.post("/profiles/{profile_id}/check-ins", status_code=201)
def check_in(profile_id: str, body: CheckIn, request: Request):
    require_profile(request, profile_id)
    request.app.state.repository.check_in(profile_id, body.mood, body.note)
    return {"saved": True}


@router.get("/profiles/{profile_id}/check-ins")
def check_ins(profile_id: str, request: Request):
    require_profile(request, profile_id)
    return request.app.state.repository.check_ins(profile_id)


@router.post("/chat", response_model=ChatResponse)
async def chat(
    body: ChatRequest,
    request: Request,
    response: Response,
    backend: Literal["live", "local", "mock"] | None = None,
    workflow: Literal["guided", "autonomous"] | None = None,
):
    started = perf_counter()
    LAST_RUN_DIAGNOSTICS.set(RequestDiagnostics())
    urgent = is_urgent(body.message)
    if urgent:
        result = AgentOutput(reply=URGENT_REPLY)
    else:
        require_profile(request, body.profile_id)
        if body.mode != Mode.TEXT_ONLY and not body.consent_to_use_vitals:
            raise HTTPException(
                403,
                "Consent is required for vitals-enabled modes; choose text only to continue without sharing readings",
            )
        context = RestrictedContextProvider(
            getattr(request.state, "comparison_context", request.app.state.context),
            body,
        )
        # Keep memory keys isolated even when direct API clients reuse session IDs.
        chosen_backend = backend or request.app.state.backend
        chosen_workflow = workflow or request.app.state.settings.workflow
        scope = json.dumps(
            [
                body.session_id,
                body.profile_id,
                body.mode.value,
                body.consent_to_use_vitals,
                chosen_backend,
                chosen_workflow,
            ],
            separators=(",", ":"),
        )
        agent_request = body.model_copy(
            update={"session_id": hashlib.sha256(scope.encode("utf-8")).hexdigest()}
        )
        freshness_token = FRESHNESS_MINUTES.set(
            request.app.state.settings.stale_after_minutes
        )
        try:
            operation = (
                request.app.state.agent(agent_request, context)
                if request.app.state.injected_agent
                or (backend is None and workflow is None)
                else invoke(agent_request, context, chosen_backend, chosen_workflow)
            )
            result = AgentOutput.model_validate(
                await asyncio.wait_for(
                    operation,
                    timeout=max(
                        0,
                        request.app.state.settings.agent_timeout_seconds
                        - (perf_counter() - started),
                    ),
                )
            )
        except TimeoutError:
            raise HTTPException(504, "Agent timed out; please try again") from None
        except Exception:
            logger.error("Agent failed; request content omitted")
            raise HTTPException(502, "Agent unavailable; please try again") from None
        finally:
            FRESHNESS_MINUTES.reset(freshness_token)
    response.headers["X-MindSync-Backend"] = backend or request.app.state.backend
    response.headers["X-MindSync-Workflow"] = (
        "guided"
        if (backend or request.app.state.backend) == "local"
        else workflow or request.app.state.settings.workflow
    )
    diagnostics = LAST_RUN_DIAGNOSTICS.get() or {}
    response.headers["X-MindSync-Outcome"] = (
        "urgent_support"
        if urgent
        else diagnostics.get("terminal_reason")
        or diagnostics.get("generation_outcome")
        or "unscored_response"
    )
    return ChatResponse(
        **result.model_dump(),
        mode=body.mode,
        safety_route="urgent_support" if urgent else "ordinary_support",
        latency_ms=max(0, int((perf_counter() - started) * 1000)),
    )


@router.post("/compare")
async def compare(
    body: ChatRequest,
    request: Request,
    backend: Literal["live", "local", "mock"] | None = None,
    workflow: Literal["guided", "autonomous"] | None = None,
):
    """One fixed synthetic snapshot; three fresh, independently restricted sessions."""
    from uuid import uuid4
    from .context_service import SnapshotContextProvider

    snapshot_at = datetime.now(timezone.utc)
    if not is_urgent(body.message):
        require_profile(request, body.profile_id)
        if not body.consent_to_use_vitals:
            raise HTTPException(
                403, "Consent is required to compare vitals-enabled modes"
            )
        request.state.comparison_context = SnapshotContextProvider.capture(
            request.app.state.repository,
            body.profile_id,
            request.app.state.settings.stale_after_minutes,
            snapshot_at,
        )
    run_id = uuid4().hex
    results = []
    for mode in Mode:
        mode_request = body.model_copy(
            update={"session_id": f"compare:{run_id}:{mode.value}", "mode": mode}
        )
        headers = Response()
        try:
            result = await chat(mode_request, request, headers, backend, workflow)
            diagnostics = LAST_RUN_DIAGNOSTICS.get() or {}
            results.append(
                {
                    "mode": mode.value,
                    "response": result.model_dump(mode="json"),
                    "backend": headers.headers["X-MindSync-Backend"],
                    "workflow": headers.headers["X-MindSync-Workflow"],
                    "outcome": headers.headers["X-MindSync-Outcome"],
                    "rag_evidence_ids": diagnostics.get("rag_evidence_ids", []),
                    "rag_fingerprint": diagnostics.get("rag_fingerprint"),
                    "context_available": diagnostics.get("context_results", {}),
                    "error": None,
                }
            )
        except HTTPException as exc:
            results.append(
                {
                    "mode": mode.value,
                    "response": None,
                    "outcome": "request_failed",
                    "error": str(exc.detail),
                    "status_code": exc.status_code,
                }
            )
    fingerprints = [row.get("rag_fingerprint") for row in results]
    return {
        "run_id": run_id,
        "snapshot_at": snapshot_at.isoformat(),
        "profile_id": body.profile_id,
        "message": body.message,
        "simulated": True,
        "identical_rag_evidence": all(fingerprints) and len(set(fingerprints)) == 1,
        "evidence_comparison_applicable": any(fingerprints),
        "results": results,
    }
