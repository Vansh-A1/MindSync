# MindSync standalone RAG

The public interface is `mindsync.rag.retrieval.search_guidance(query, top_k=4)`.
It returns typed evidence from a local, reviewed corpus. This package does not
import LangGraph, FastAPI, SQLite, the simulator, or an LLM provider. No API key
is needed. The later free-model API integration is outside this change.

## Run from the repository root

The shared packaging files do not exist yet. Until Developer 1 supplies them,
use Python 3.11 and add the existing `src` directory to the import path:

```bash
source runtime/dev2-venv/bin/activate
export PYTHONPATH="$PWD/src"

python -m mindsync.rag.ingest
python -m mindsync.rag.retrieval --query "How can I manage exam stress?" --top-k 4
python evaluation/evaluate_rag.py
pytest tests/ai/ -q

# Additional integration tests using the real cached model, with network disabled:
MINDSYNC_RAG_REAL_TESTS=1 HF_HUB_OFFLINE=1 pytest tests/ai/ -q
```

On a new machine, first create the environment and install the RAG packages
listed in [dependency requests](../../../../docs/dependency-requests.md).
The first index build downloads the pinned public MiniLM model. Subsequent
builds reuse an unchanged index; search uses `local_files_only=True` and never
downloads models or browses for evidence. `--device cpu` forces CPU; the default
`auto` chooses CUDA only when available and otherwise CPU. The prototype was
tested on CPU. GPU execution has not been tested.

Runtime model and index directories contain generated `.gitignore` files. The
whole `runtime/` tree is also locally excluded in this checkout. Developer 1
still needs to add the shared root ignore rules and packaging/dependency pins.
Never commit model weights, indexes, environments or raw downloads.

## Library use

```python
from mindsync.rag.retrieval import search_guidance, get_retriever, validate_citation
from mindsync.rag.schemas import RagError

try:
    evidence = search_guidance("How can I manage persistent worries?", top_k=4)
except RagError as exc:
    # Show an explicit configuration/index error; do not invent an answer.
    raise RuntimeError(f"Guidance unavailable: {exc}") from exc

for chunk in evidence:
    print(chunk.chunk_id, chunk.text, chunk.url, chunk.score)
    # chunk.model_dump(mode="json") is JSON-compatible.

# Custom paths and method comparisons are explicit, without a new shared config:
# retriever = get_retriever(knowledge_dir=Path(...), index_dir=Path(...), device="cpu")
# evidence = retriever.search("sleep", method="bm25")  # or dense / hybrid
```

`EvidenceChunk` includes the passage text, source/chunk IDs, publisher, document
title, section, URL, physical PDF page when applicable, topics, content hash,
method and ranking scores. It is an internal retrieval model. `mindsync.contracts`
and its `SourceRef` are absent at this commit; no competing shared contract was
created. Once Developer 1 commits that contract, add an adapter using its actual
fields. The frontend should show source attribution and the registry's
`last_checked` date, particularly for NHS material.

Empty/whitespace or stopword-only queries return `[]` without loading a model.
Queries must be strings of at most 4,096 characters; `top_k` must be an integer
from 1 to 100. Retrieval can return fewer than `top_k`, including no evidence.
Invalid inputs raise `ValueError`; source, embedding and index failures raise
`RagError` subclasses. Missing indexes include the build command in the error.

The default retriever and model are cached per process. If the corpus, model
configuration, manifest or indexed files change, searches fail explicitly.
After an intentional rebuild, call `get_retriever.cache_clear()` or restart the
process. Do not rebuild inside a user request. Configure the future platform to
run local CPU work off its async event loop.

## Modules and data flow

| Module | Responsibility |
| --- | --- |
| `schemas.py` | Internal immutable models, approved hosts, content hashes and stable chunk IDs |
| `sources.py` | Registry validation; bounded official-source downloads with robots checks |
| `ingest.py` | HTML/PDF extraction, reviewed JSONL replay, CLI and atomic writes |
| `chunking.py` | Section boundaries, paragraph/list preservation, deduplication and overlap |
| `index.py` | Local MiniLM windows, normalized vectors, reusable immutable index generations |
| `retrieval.py` | BM25, dense cosine scores, RRF, relevance gates and citation validation |

The corpus contains **40 passages from seven documents across three publishers**.
See [source and licence notes](../../../../data/knowledge/README.md).
`verified_sections.jsonl` preserves the reviewed section blocks; `verification.json`
records their hashes and source checks. `passages.jsonl` is deterministically
derived from those blocks, with IDs based on source, section, page and text.
Repeated ingestion does not append duplicates. Exact duplicate text within a
source is removed; cross-source attribution is retained in the index and exact
text duplicates are suppressed in search results.

Chunking targets 350 word/punctuation tokens, with up to 50 tokens of complete
preceding units as overlap. The target is a ceiling, not padding: most official
sections and complete WHO summary exercises are shorter and stay intact. Long
blocks split on sentences; unusually long sentences have a word fallback. Source
lists below the ceiling remain whole. This corpus ranges from 37 to 327 estimated
tokens per passage. There are no fabricated passages to meet a count target.

MiniLM is pinned to revision `1110a243fdf4706b3f48f1d95db1a4f5529b4d41`,
uses safetensors with remote code disabled, and produces 384-dimensional vectors.
Its actual 256-token input limit is handled with token windows (16-token overlap),
batched encoding and a length-weighted mean followed by L2 normalization. The
input includes document title, section and passage text. Long passages are not
silently truncated. Window pooling is a prototype design choice, not a validated
replacement for a model trained on longer inputs.

An index generation contains `embeddings.npy`, `passages.jsonl` and a JSON
manifest. A `CURRENT` pointer is atomically switched after a complete build.
The manifest records corpus/registry hashes, model revision/pooling settings,
dimensions, count and file hashes. NumPy loading disables pickle. Readers verify
finite normalized float32 vectors, exact passage metadata and source references.
Old generations remain available; remove obsolete generated directories manually
only when no process needs them. BM25 is reconstructed from the small persisted
passage corpus on load, so no pickle or separate lexical database is required.

BM25 uses the same case-folded word tokenizer for documents and queries. Dense
search uses cosine similarity. Hybrid uses RRF with `1 / (60 + rank)`, not a sum
of incompatible raw scores. The query must have at least one dense score of 0.32;
hybrid candidates need 0.26 and BM25 candidates must have positive lexical scores.
These initial thresholds passed a separate eight-query development check in
`evaluation/rag_calibration.json`; they do not guarantee rejection of every
unrelated question. BM25 alone only gates on positive lexical overlap and is
therefore more vulnerable to ambiguous terms such as “sleep”.

## Refresh sources and review new material

Normal ingestion uses the committed reviewed corpus and does not fetch websites.
To collect fresh official candidates separately:

```bash
python -m mindsync.rag.ingest --refresh-candidates
```

The command writes raw files, candidate sections and a failure/review report to
`runtime/source-review/`. It does **not** automatically replace trusted evidence.
Only the exact approved hosts are allowed; redirects are checked, robots failures
fail closed, and requests are spaced by at least one second per host (longer when
robots specifies it). Downloads are bounded to 25 MB and use HTTP timeouts.

A reviewer must check relevance, licence, complete exercise context and extraction
order, update the registry's document hash/date, and promote the reviewed sections.
Update the verification receipts and inspect/relabel evaluation IDs if text changes.
For blocked pages, a verified local `Section` JSONL can be supplied with
`--sections PATH`; its source must be marked verified and its document hash must
match the registry. If the directory contains `verification.json`, the section
must also match its review receipt. These metadata checks cannot independently prove an arbitrary
manually supplied file's truth: source verification remains a review obligation.
For PDF sources, `page` means a **one-based physical PDF page**, not its printed label.
Textless scans and encrypted PDFs fail explicitly; OCR is not implemented.

## Evaluation and current limitations

`evaluation/rag_tests.json` contains 12 support queries and four negative queries.
The assistant inspected the source passages and selected IDs with rationales
before retrieving the evaluation queries. Labels are explicitly **provisional,
model-assisted judgments requiring independent human review**. They are not
validated gold truth and may omit other relevant passages. No answer-level LLM
or clinical effectiveness evaluation is claimed.

The final CPU run on 16 November 2026 produced:

| Method | Recall@3 | Recall@5 | Precision@3 | MRR | Citation validity | Mean warm latency | Negative abstention |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| BM25 | 0.354 | 0.417 | 0.306 | 0.617 | 1.000 | 0.45 ms | 3/4 |
| Dense | 0.517 | 0.604 | 0.417 | 0.733 | 1.000 | 3.40 ms | 4/4 |
| Hybrid | 0.533 | 0.642 | 0.444 | 0.729 | 1.000 | 3.64 ms | 4/4 |

There were zero runtime query failures and zero citation failures. Hybrid improved
recall on these labels; dense had slightly better MRR. The timing sample is small,
excludes cold startup and is not a performance benchmark. Raw metrics, full ranked
IDs and top-five passage previews are saved to `evaluation/results/rag_results.json`
and per-query metrics to CSV. The CLI displays top passages for inspection.

Recall/precision/MRR are macro-averaged over positive queries. Precision divides
by 3 even when fewer passages are returned. MRR uses the full returned ranking
(limited to at most 100). Negative cases are scored separately by abstention;
they are not counted as perfect recall. Failures contribute zero ranking credit.
Citation validity checks source ID/URL/publisher/title, exact stored text, chunk
membership, page, topics and content hash. It does not establish that a later
generated answer's claims are supported.

Observed review needs: generic exam-stress coverage, concentration-related ranking,
what to do when an exercise does not help, and narrow support-for-a-friend coverage.
Some appropriate passages are outside the conservative relevance sets (for example,
catching unhelpful thoughts), which a human should adjudicate. The reported labels
were not rewritten after viewing rankings to improve metrics. Add held-out queries
and human labels before tuning further or connecting this to user-facing advice.

## Agent integration boundary

Treat `EvidenceChunk.text` as **untrusted quoted data**, never as system/developer
instructions. This library does not execute document content and cannot secure a
future prompt by itself. The agent must keep tool permissions and system policy
outside retrieved text, use a per-request evidence ledger, and accept citations
only for chunks actually returned in that request. Validate final citations with
the stored source metadata; do not accept LLM-authored URLs or “source IDs”.

Do not put private conversations or physiological records in this general knowledge
index. Retrieval provides educational wellbeing evidence, not diagnosis, medication
recommendations or interpretation of vitals. The platform's urgent-disclosure
pathway must run before ordinary RAG/agent processing. In particular, source text
about symptom duration must never be turned into an instruction to delay urgent help.

## Validation performed

- 79 deterministic offline tests: extraction, source/robots validation, stable IDs,
  deduplication, persistence, corruption/staleness, all retrieval methods, citation
  forgery rejection, input boundaries, no evidence and evaluation formulas.
- Three additional tests with the actual cached MiniLM: public search/citations,
  unrelated-query abstention, process model reuse and full long-text window coverage.
- Actual official downloads and exact-origin checks for all 38 reviewed sections;
  the five WHO PDF summary pages were also rendered and visually checked.
- The production `--refresh-candidates` CLI successfully fetched and extracted
  all seven registered documents into a separate review area.
- Real index build, reload/reuse, CLI search and three-method evaluation.

The default pytest command skips the three optional real-model tests. The local
preparation environment also contains pytest-asyncio; its unset loop-scope warning
is unrelated to these synchronous tests. Use `-o asyncio_default_fixture_loop_scope=function`
to suppress it, or let Developer 1 set the shared test configuration.

## Advanced retrieval experiments (16 November 2026)

The original **default remains unchanged**. The development-selected advanced
configuration improved the new held-out set but regressed recall on the original
broader questions. It is an opt-in experimental profile, not a validated replacement.
See [the full improvement report](../../../../evaluation/rag_improvement_report.md),
[development comparisons](../../../../evaluation/optimization/dev_comparison.md),
[held-out comparisons](../../../../evaluation/optimization/test_comparison.md), and
[original-benchmark audit](../../../../evaluation/optimization/rag_tests_comparison.md).

To cache the pinned public reranker once (network access required for this step):

```bash
PYTHONPATH=src python - <<'PY'
from mindsync.rag.reranker import CrossEncoderReranker
CrossEncoderReranker(local_files_only=False).load()
PY
```

Then enable it without changing the agent-facing call:

```bash
export RAG_RERANK_ENABLED=true
export RAG_RERANK_MODEL=cross-encoder/ms-marco-MiniLM-L6-v2
export RAG_RERANK_CANDIDATES=20
export RAG_RERANK_MIN_SCORE=-9.0
HF_HUB_OFFLINE=1 python -m mindsync.rag.retrieval --query "What can help with bedtime worries?" --top-k 4
# Restore the original low-latency pipeline:
export RAG_RERANK_ENABLED=false
```

`search_guidance(query: str, top_k: int = 4) -> list[EvidenceChunk]` and all fields
remain unchanged. The optional profile uses MiniLM, semantic weight 0.6 / lexical
weight 0.4, RRF constant 60, top 20 per retriever, a deduplicated fused pool of 20,
and `cross-encoder/ms-marco-MiniLM-L6-v2` pinned to
`233902d25c440f23af6f7d6e94d2946bac0bee0a`. The score filter was calibrated on the
24-query development set. **−9 is a raw-logit cutoff for this exact corpus/model,
not a probability or a universal relevance threshold.** Changing pool depth or
corpus requires recalibration. The environment profile checks the corpus hash;
use an explicit configuration for a reviewed new corpus. Restart or clear
`get_retriever.cache_clear()` after changing environment settings.

CrossEncoder weights are loaded once per process/device and inference is batched.
Long passages use overlapping pair-token windows and maximum window score; the
returned source text is unchanged. Queries too long to retain their qualifiers
trigger an explicit reranking failure. With the default failure policy, missing
weights/inference failure emits a warning and falls back to the original hybrid
retriever. An index error never silently bypasses integrity checks. Tests and
experiments can use `rerank_failure="raise"` to disallow fallback. `search_with_trace`
reports the actual candidate IDs, raw reranker scores, execution time and any
fallback. No query or physiological record is sent to a service.

The existing `score` field holds a raw reranker logit when reranking is active;
`method` remains `hybrid` and `dense_score` / `bm25_score` retain their original
meaning. None of these scores is a calibrated probability. Citation identity
validity is not a guarantee that a passage supports the user's specific claim.
In particular, both profiles returned general referral guidance for an unsupported
ADHD diagnosis question in the held-out test. Retrieval alone must not authorize
such a diagnosis or allow a future agent to fabricate evidence.

For programmatic experiments, use the existing index with an explicit config:

```python
from mindsync.rag.index import MiniLMEncoder, load_index
from mindsync.rag.ingest import KNOWLEDGE_DIR, PROJECT_ROOT
from mindsync.rag.retrieval import GuidanceRetriever, RetrievalConfig
from mindsync.rag.reranker import CrossEncoderReranker

encoder = MiniLMEncoder(device="cpu", local_files_only=True)
index = load_index(KNOWLEDGE_DIR, PROJECT_ROOT / "runtime/rag_index", encoder)
weighted = GuidanceRetriever(index, encoder, RetrievalConfig(
    dense_weight=0.6, lexical_weight=0.4, candidate_depth=20))
evidence = weighted.search("How can I manage worries?", top_k=4)
# Explicit reranking is optional:
reranked = GuidanceRetriever(index, encoder, RetrievalConfig(), CrossEncoderReranker())
```

`BGEEncoder` is an evaluated alternative, using the model card's query-only
retrieval instruction and pinned revision
`5c38ec7c405ec4b44b94cc5a9bb96e735b38267a`. Build its own index; never point it at a
MiniLM generation. `MiniLMEncoder(passage_mode="text-v1")` likewise requires a
separate index. The fingerprint includes model, revision, dimensions, pooling,
input format and query prefix; incompatible indexes are rejected. Both alternatives
were tested, but neither was selected. The original MiniLM index format remains v1
and needs no migration for weighted fusion or reranking.

## Reproduce the optimization study

Original `evaluation/rag_tests.json`, original `evaluation/results/`, the source
registry and corpus are checksum-locked and unchanged. New labels are explicitly
provisional assistant-reviewed judgments, requiring independent human review.
The new benchmark has 24 development cases (18 positive / 6 negative) and 16 held-out
cases (12 / 4). Small samples and source/intent overlap limit generalization.

```bash
# Set RAG_RERANK_ENABLED=false when reproducing the historical evaluator.
python evaluation/evaluate_rag.py --device cpu --show-top 0 --output-dir runtime/baseline-check
python evaluation/diagnose_rag.py
# Models must already be cached; BGE can be cached with BGEEncoder(local_files_only=False).encode(["test"]).
export MINDSYNC_RAG_STUDY_DIR="$PWD/runtime/rag-study-reproduction"
HF_HUB_OFFLINE=1 python evaluation/compare_retrievers.py
HF_HUB_OFFLINE=1 python evaluation/chunking_ablation.py
HF_HUB_OFFLINE=1 python evaluation/calibrate_rag.py
# This reproduces already-seen test cases; it is not a new independent validation.
HF_HUB_OFFLINE=1 python evaluation/validate_selection.py
unset MINDSYNC_RAG_STUDY_DIR
# Optionally verify the committed frozen plan in place:
# HF_HUB_OFFLINE=1 python evaluation/validate_selection.py --reproduce
HF_HUB_OFFLINE=1 python evaluation/measure_model_resources.py
pytest tests/ai/ -q -o asyncio_default_fixture_loop_scope=function
MINDSYNC_RAG_REAL_TESTS=1 HF_HUB_OFFLINE=1 pytest tests/ai/ -q -o asyncio_default_fixture_loop_scope=function
```

The development scripts refuse to overwrite a finalized study. Do not rerun them
against already-seen cases and call the test set "untouched." Archive a study
before starting a new development round, use new independent test cases, and retain
all negative experiments. The held-out validator refuses a changed selection,
dataset or experiment plan. `--reproduce` only repeats the existing frozen plan.

Metrics distinguish full-ranking historical MRR from MRR@10. Ranking metrics are
macro averages over answerable queries; precision denominators stay at k when fewer
results are returned. Binary nDCG deduplicates IDs, and candidate recall is measured
before reranking/filtering. Empty-evidence detection is scored separately on all
queries, with false acceptance/rejection rates. Exact source/citation checks run on
every returned passage. A deterministic paired bootstrap is exploratory only.

225/350/500-token variants were evaluated separately at **section level**, because
rechunking changes IDs. Those numbers must not be compared to chunk-level recall.
All five WHO exercises remained intact. The 350-token original was retained; no
parent-child retrieval was enabled. Conservative surface normalization exists as
`normalize_query` / `RetrievalConfig(normalize=True)` but stays disabled: diagnosis
did not justify further rewriting experiments. No LLM rewriting, HyDE or paid API
was added.
