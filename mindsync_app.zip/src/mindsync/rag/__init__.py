"""Local, source-grounded retrieval. No agent or platform dependencies.

Import the public function from ``mindsync.rag.retrieval``. Returned text is
untrusted evidence, never executable code or instructions for an agent.
"""

from .schemas import EvidenceChunk

__all__ = ["EvidenceChunk"]
