"""Section-aware chunks with complete short lists and bounded sentence overlap."""

from __future__ import annotations

import re

from .schemas import Passage, Section, SourceError, SourceRecord, clean_text, digest, make_chunk_id


def token_count(text: str) -> int:
    """Conservative word/punctuation estimate; embedding uses actual token windows."""
    return len(re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE))


def _units(block: str, target: int) -> list[str]:
    if token_count(block) <= target:
        return [block]
    sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"‘“])", block)
    units = []
    for sentence in sentences:
        if token_count(sentence) <= target:
            units.append(sentence)
        else:
            # Even punctuation-heavy or unpunctuated text is bounded.
            words, current = sentence.split(), []
            for word in words:
                if current and token_count(" ".join([*current, word])) > target:
                    units.append(" ".join(current))
                    current = []
                current.append(word)
            if current:
                units.append(" ".join(current))
    return units


def chunk_sections(sections: list[Section], sources: dict[str, SourceRecord],
                   target_tokens: int = 350, overlap_tokens: int = 50) -> list[Passage]:
    if not 0 <= overlap_tokens < target_tokens or target_tokens < 10:
        raise ValueError("Require target >= 10 and 0 <= overlap < target")
    passages, seen = [], set()
    for section in sections:
        source = sources.get(section.source_id)
        if source is None or source.verification_status != "verified":
            raise SourceError(f"Cannot chunk unverified source {section.source_id}")
        if section.document_sha256 != source.download_sha256:
            raise SourceError(f"Document provenance mismatch for {section.source_id}")
        # Deduplicate exact paragraphs within a section, not across exercises.
        blocks = list(dict.fromkeys(section.blocks))
        units = [unit for block in blocks for unit in _units(block, target_tokens)]
        chunks, current = [], []
        for unit in units:
            if current and token_count(" ".join([*current, unit])) > target_tokens:
                chunks.append(" ".join(current))
                overlap = []
                for prior in reversed(current):
                    if token_count(" ".join([prior, *overlap])) > overlap_tokens:
                        break
                    overlap.insert(0, prior)
                current = overlap
                if token_count(" ".join([*current, unit])) > target_tokens:
                    current = []
            current.append(unit)
        if current:
            chunks.append(" ".join(current))
        for text in chunks:
            text = clean_text(text)
            content_hash = digest(text)
            # Same text in two sources retains independent provenance.
            key = (source.source_id, content_hash)
            if key in seen:
                continue
            seen.add(key)
            passages.append(Passage(
                chunk_id=make_chunk_id(source.source_id, section.section, section.page, text),
                source_id=source.source_id, publisher=source.publisher, title=source.title,
                section=section.section, url=source.url, text=text, page=section.page,
                topics=source.topics, content_hash=content_hash,
            ))
    return sorted(passages, key=lambda p: p.chunk_id)
