"""Local MiniLM encoding and immutable, integrity-checked NumPy index generations."""

from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import numpy as np

from .ingest import PROJECT_ROOT, atomic_text, load_passages, write_jsonl
from .schemas import IndexError, Passage, RagError, SourceRecord, StaleIndexError, digest
from .sources import load_sources

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
MODEL_REVISION = "1110a243fdf4706b3f48f1d95db1a4f5529b4d41"
INDEX_VERSION = 1


class Encoder(Protocol):
    @property
    def fingerprint(self) -> dict: ...

    def encode(self, texts: list[str]) -> np.ndarray: ...


class MiniLMEncoder:
    """Load once per process/device. All text is encoded, including long chunks.

    MiniLM's 256-token input limit is handled by token windows with a 16-token
    overlap and a length-weighted mean, then L2 normalization. No remote API.
    """

    _models: dict[tuple, object] = {}
    _lock = threading.Lock()
    model_name = MODEL_NAME
    model_revision = MODEL_REVISION
    dimensions = 384
    token_limit = 256
    query_prefix = ""

    def __init__(self, *, device: str = "auto", local_files_only: bool = False,
                 cache_dir: Path | None = None, batch_size: int = 32,
                 passage_mode: str = "title-section-text-v1"):
        if device not in {"cpu", "auto", "cuda"} or batch_size < 1:
            raise ValueError("Invalid embedding device or batch size")
        self.device = device
        self.local_files_only = local_files_only
        self.cache_dir = cache_dir or PROJECT_ROOT / "runtime/huggingface"
        self.batch_size = batch_size
        if passage_mode not in {"title-section-text-v1", "text-v1"}:
            raise ValueError("Unsupported passage input mode")
        self.passage_mode = passage_mode

    @property
    def fingerprint(self) -> dict:
        result = {"name": self.model_name, "revision": self.model_revision, "dimensions": self.dimensions,
                  "pooling": f"token-windows-{self.token_limit}-overlap16-weighted-mean-v1",
                  "normalize": True, "passage_input": self.passage_mode}
        if self.query_prefix:
            result["query_prefix"] = self.query_prefix
        return result

    def encode_queries(self, texts: list[str]) -> np.ndarray:
        return self.encode([self.query_prefix + text for text in texts])

    def _model(self):
        # Set cache/privacy defaults before importing Hugging Face modules.
        os.environ.setdefault("HF_HOME", str(self.cache_dir))
        os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
        os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        if not (self.cache_dir / ".gitignore").exists():
            atomic_text(self.cache_dir / ".gitignore", "*\n")
        import torch
        from sentence_transformers import SentenceTransformer
        device = self.device
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        if device == "cuda" and not torch.cuda.is_available():
            raise IndexError("CUDA requested but unavailable; select --device cpu")
        key = (self.model_name, self.model_revision, device, str(self.cache_dir.resolve()))
        with self._lock:
            if key not in self._models:
                try:
                    self._models[key] = SentenceTransformer(
                        self.model_name, revision=self.model_revision, device=device,
                        cache_folder=str(self.cache_dir / "hub"), token=False,
                        trust_remote_code=False, local_files_only=self.local_files_only,
                        model_kwargs={"use_safetensors": True},
                    )
                except Exception as exc:
                    raise IndexError(f"{self.model_name} is unavailable. Build the index once with network access "
                                     "to cache its pinned model, then search offline.") from exc
            return self._models[key]

    def encode(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.empty((0, self.dimensions), dtype=np.float32)
        model = self._model()
        tokenizer = model.tokenizer
        capacity = min(model.max_seq_length, self.token_limit) - tokenizer.num_special_tokens_to_add()
        windows, owners, weights = [], [], []
        for owner, text in enumerate(texts):
            tokens = tokenizer.encode(text, add_special_tokens=False, truncation=False, verbose=False)
            if not tokens:
                raise IndexError("Cannot embed an empty token sequence")
            for start in range(0, len(tokens), capacity - 16):
                part = tokens[start:start + capacity]
                windows.append(tokenizer.decode(part, skip_special_tokens=True))
                owners.append(owner)
                weights.append(len(part))
                if start + capacity >= len(tokens):
                    break
        try:
            vectors = model.encode(windows, batch_size=self.batch_size, convert_to_numpy=True,
                                   normalize_embeddings=False, show_progress_bar=False)
        except Exception as exc:
            raise IndexError(f"Local embedding failed: {type(exc).__name__}") from exc
        pooled = np.zeros((len(texts), self.dimensions), dtype=np.float32)
        for owner, weight, vector in zip(owners, weights, vectors, strict=True):
            pooled[owner] += weight * vector
        norms = np.linalg.norm(pooled, axis=1, keepdims=True)
        if not np.isfinite(pooled).all() or not np.isfinite(norms).all() or np.any(norms == 0):
            raise IndexError("Embedding model produced nonfinite or zero vectors")
        return pooled / norms


class BGEEncoder(MiniLMEncoder):
    """Pinned BGE v1.5; documented retrieval instruction on queries only."""

    model_name = "BAAI/bge-small-en-v1.5"
    model_revision = "5c38ec7c405ec4b44b94cc5a9bb96e735b38267a"
    token_limit = 512
    query_prefix = "Represent this sentence for searching relevant passages: "


def passage_input(passage: Passage, mode: str = "title-section-text-v1") -> str:
    if mode == "text-v1":
        return passage.text
    if mode != "title-section-text-v1":
        raise ValueError("Unsupported passage input mode")
    return f"{passage.title}. {passage.section}. {passage.text}"


def _file_hash(path: Path) -> str:
    try:
        return digest(path.read_bytes())
    except OSError as exc:
        raise IndexError(f"Cannot read index/corpus file: {path}") from exc


def corpus_signature(knowledge: Path) -> dict:
    return {"sources_sha256": _file_hash(knowledge / "sources.json"),
            "passages_sha256": _file_hash(knowledge / "passages.jsonl")}


@dataclass(frozen=True)
class LoadedIndex:
    passages: tuple[Passage, ...]
    vectors: np.ndarray
    sources: dict[str, SourceRecord]
    manifest: dict
    directory: Path
    knowledge: Path
    root: Path
    manifest_hash: str

    def assert_current(self) -> None:
        if corpus_signature(self.knowledge) != self.manifest["corpus"]:
            raise StaleIndexError("Knowledge changed; rebuild with python -m mindsync.rag.ingest")
        try:
            current = (self.root / "CURRENT").read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise IndexError("Index CURRENT pointer is missing") from exc
        if current != self.directory.name:
            raise StaleIndexError("Index generation changed; create a fresh retriever")
        if _file_hash(self.directory / "manifest.json") != self.manifest_hash:
            raise IndexError("Index manifest changed after loading")
        for filename, expected in self.manifest["files"].items():
            if _file_hash(self.directory / filename) != expected:
                raise IndexError(f"Index integrity check failed: {filename}")


def load_index(knowledge: Path, index_dir: Path, encoder: Encoder) -> LoadedIndex:
    try:
        generation = (index_dir / "CURRENT").read_text(encoding="utf-8").strip()
    except FileNotFoundError as exc:
        raise IndexError("Index not built. Run: python -m mindsync.rag.ingest") from exc
    except OSError as exc:
        raise IndexError(f"Cannot read index at {index_dir}") from exc
    if not re.fullmatch(r"[0-9a-f]{32}", generation):
        raise IndexError("Invalid index generation pointer")
    directory = index_dir / "generations" / generation
    try:
        manifest_bytes = (directory / "manifest.json").read_bytes()
        manifest = json.loads(manifest_bytes)
        if not isinstance(manifest, dict):
            raise IndexError("Index manifest must be an object")
        if manifest["version"] != INDEX_VERSION or manifest["encoder"] != encoder.fingerprint:
            raise StaleIndexError("Index format or embedding model changed; rebuild the index")
        if manifest["corpus"] != corpus_signature(knowledge):
            raise StaleIndexError("Corpus/source registry changed; rebuild the index")
        if not isinstance(manifest["files"], dict) or set(manifest["files"]) != {"embeddings.npy", "passages.jsonl"}:
            raise IndexError("Invalid index file manifest")
        for filename, expected in manifest["files"].items():
            if _file_hash(directory / filename) != expected:
                raise IndexError(f"Index file hash mismatch: {filename}")
        sources = load_sources(knowledge / "sources.json")
        passages = load_passages(directory / "passages.jsonl", sources)
        canonical = load_passages(knowledge / "passages.jsonl", sources)
        if passages != canonical:
            raise IndexError("Indexed passages differ from the verified corpus")
        vectors = np.load(directory / "embeddings.npy", allow_pickle=False)
        if not isinstance(vectors, np.ndarray):
            vectors.close()
            raise IndexError("Expected a single NumPy array, not an archive")
        expected_shape = (len(passages), encoder.fingerprint["dimensions"])
        if vectors.shape != expected_shape or manifest["shape"] != list(expected_shape):
            raise IndexError("Embedding dimensions/chunk counts do not match")
        if vectors.dtype != np.float32 or not np.isfinite(vectors).all():
            raise IndexError("Embeddings must be finite float32 values")
        if not np.allclose(np.linalg.norm(vectors, axis=1), 1, atol=1e-4):
            raise IndexError("Embedding vectors are not normalized")
        vectors.setflags(write=False)
        return LoadedIndex(tuple(passages), vectors, sources, manifest, directory,
                           knowledge, index_dir, digest(manifest_bytes))
    except RagError:
        raise
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise IndexError(f"Invalid or incomplete index at {directory}: {exc}") from exc


def build_index(knowledge: Path, index_dir: Path, encoder: Encoder) -> bool:
    """Return False when reusing a compatible index; never silently repair corruption."""
    index_dir.mkdir(parents=True, exist_ok=True)
    if not (index_dir / ".gitignore").exists():
        atomic_text(index_dir / ".gitignore", "*\n")
    if (index_dir / "CURRENT").exists():
        try:
            load_index(knowledge, index_dir, encoder)
            return False
        except StaleIndexError:
            pass
    signature = corpus_signature(knowledge)
    sources = load_sources(knowledge / "sources.json")
    passages = load_passages(knowledge / "passages.jsonl", sources)
    mode = encoder.fingerprint.get("passage_input", "title-section-text-v1")
    vectors = np.asarray(encoder.encode([passage_input(p, mode) for p in passages]), dtype=np.float32)
    shape = (len(passages), encoder.fingerprint["dimensions"])
    if vectors.shape != shape or not np.isfinite(vectors).all():
        raise IndexError("Embedding output has invalid dimensions or nonfinite values")
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if not np.isfinite(norms).all() or np.any(norms == 0):
        raise IndexError("Embedding output contains zero or invalid vector norms")
    vectors = vectors / norms
    generations = index_dir / "generations"
    generations.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".building-", dir=generations))
    try:
        np.save(staging / "embeddings.npy", vectors, allow_pickle=False)
        write_jsonl(staging / "passages.jsonl", passages)
        manifest = {"version": INDEX_VERSION, "encoder": encoder.fingerprint,
                    "corpus": signature, "shape": list(shape),
                    "files": {name: _file_hash(staging / name)
                              for name in ("embeddings.npy", "passages.jsonl")}}
        atomic_text(staging / "manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        if corpus_signature(knowledge) != signature:
            raise StaleIndexError("Corpus changed during index build; please retry")
        generation = uuid.uuid4().hex
        staging.rename(generations / generation)
        atomic_text(index_dir / "CURRENT", generation + "\n")
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    load_index(knowledge, index_dir, encoder)
    return True
