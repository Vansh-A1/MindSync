"""Extract registered documents, replay reviewed sections, and build a local index."""

from __future__ import annotations

import argparse
import io
import json
import os
import sys
import tempfile
from pathlib import Path

from bs4 import BeautifulSoup
from pydantic import ValidationError

from .chunking import chunk_sections
from .schemas import Passage, RagError, Section, SourceError, SourceRecord, clean_text, digest
from .sources import OfficialDownloader, load_sources, validate_passage

from mindsync.paths import PROJECT_ROOT, KNOWLEDGE_DIR


def atomic_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     delete=False) as stream:
        temp = Path(stream.name)
        try:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            temp.unlink(missing_ok=True)
            raise
    try:
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def write_jsonl(path: Path, records: list) -> None:
    text = "".join(record.model_dump_json() + "\n" for record in records)
    # Idempotent builds preserve the file and its timestamp when unchanged.
    if path.exists() and path.read_text(encoding="utf-8") == text:
        return
    atomic_text(path, text)


def extract_html(body: bytes, source: SourceRecord) -> list[Section]:
    if not body.strip():
        raise SourceError(f"Empty HTML for {source.source_id}")
    soup = BeautifulSoup(body, "html.parser")
    root = soup.select_one(source.content_selector)
    if root is None:
        raise SourceError(f"Content selector missing for {source.source_id}")
    for node in root.select("nav,footer,header,script,style,form,aside,iframe,"
                            ".nhsuk-card,.advertisement,.social-share"):
        node.decompose()
    sections, blocks = [], []
    heading = source.title
    allowed = set(source.section_allowlist)

    def flush() -> None:
        if blocks and (not allowed or heading in allowed):
            sections.append(Section(source_id=source.source_id, section=heading,
                                    blocks=tuple(dict.fromkeys(blocks)),
                                    document_sha256=digest(body)))

    for node in root.find_all(["h1", "h2", "h3", "h4", "p", "ul", "ol"]):
        # A list is a coherent unit; nested paragraphs/lists must not repeat it.
        if node.find_parent(["ul", "ol"]) is not None:
            continue
        text = clean_text(node.get_text(" ", strip=True))
        if not text:
            continue
        if node.name.startswith("h"):
            flush()
            heading, blocks = text, []
        else:
            blocks.append(text)
    flush()
    if not sections:
        raise SourceError(f"No selected text sections for {source.source_id}")
    return sections


def extract_pdf(body: bytes, source: SourceRecord,
                pages: dict[int, str]) -> list[Section]:
    """Extract explicitly selected, one-based physical PDF pages (not printed labels).

    Page selections need human review for reading order and complete exercises.
    Scans without a text layer fail explicitly; no invented OCR text is supplied.
    """
    from pypdf import PdfReader
    try:
        reader = PdfReader(io.BytesIO(body), strict=True)
        if reader.is_encrypted:
            raise SourceError("Encrypted PDFs are not supported")
        sections = []
        for page, heading in sorted(pages.items()):
            if not 1 <= page <= len(reader.pages):
                raise SourceError(f"Invalid PDF page {page}")
            lines = (reader.pages[page - 1].extract_text() or "").splitlines()
            lines = [clean_text(line) for line in lines if clean_text(line)]
            # Remove page number, repeated heading, summary footer and audio-link
            # callout. Content remains in PDF reading order and is reviewed below.
            if lines and lines[0].isdigit():
                lines.pop(0)
            if lines and lines[0] == heading:
                lines.pop(0)
            cleaned = []
            for line in lines:
                if line == "Summary" or line == "\uf028":
                    break
                cleaned.append(line)
            text = clean_text(" ".join(cleaned))
            if not text:
                raise SourceError(f"No text layer on PDF page {page}")
            sections.append(Section(source_id=source.source_id, section=heading,
                                    blocks=(text,), page=page, document_sha256=digest(body)))
        if not sections:
            raise SourceError("At least one reviewed PDF page selection is required")
        return sections
    except SourceError:
        raise
    except Exception as exc:
        raise SourceError(f"Cannot extract PDF {source.source_id}: {type(exc).__name__}") from exc


def load_sections(path: Path, sources: dict[str, SourceRecord]) -> list[Section]:
    try:
        result = [Section.model_validate_json(line) for line in path.read_text(encoding="utf-8").splitlines()
                  if line.strip()]
        if not result:
            raise ValueError("Reviewed sections file is empty")
        for section in result:
            source = sources.get(section.source_id)
            if source is None or source.verification_status != "verified":
                raise ValueError(f"Section uses unverified source {section.source_id}")
            if source.download_sha256 != section.document_sha256:
                raise ValueError(f"Section provenance hash differs for {section.source_id}")
        receipt_path = path.parent / "verification.json"
        if receipt_path.exists():
            receipts = json.loads(receipt_path.read_text(encoding="utf-8"))
            if not isinstance(receipts, dict) or not isinstance(receipts.get("records"), list):
                raise ValueError("Verification receipts must contain a records list")
            approved = set()
            for receipt in receipts["records"]:
                if not isinstance(receipt, dict):
                    raise ValueError("Invalid verification receipt")
                approved.add((receipt.get("source_id"), receipt.get("section"), receipt.get("page"),
                              receipt.get("document_sha256"), receipt.get("section_sha256")))
            for section in result:
                identity = (section.source_id, section.section, section.page,
                            section.document_sha256, digest("\n".join(section.blocks)))
                if identity not in approved:
                    raise ValueError(f"Section differs from its verification receipt: {section.section}")
        return result
    except (OSError, ValueError, TypeError, ValidationError) as exc:
        raise SourceError(f"Invalid reviewed sections {path}: {exc}") from exc


def load_passages(path: Path, sources: dict[str, SourceRecord]) -> list[Passage]:
    try:
        result = [Passage.model_validate_json(line) for line in path.read_text(encoding="utf-8").splitlines()
                  if line.strip()]
        if not result:
            raise ValueError("Passage file is empty")
        ids = [p.chunk_id for p in result]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate chunk IDs")
        for passage in result:
            validate_passage(passage, sources)
        return sorted(result, key=lambda p: p.chunk_id)
    except (OSError, ValueError, ValidationError) as exc:
        raise SourceError(f"Invalid passages {path}: {exc}") from exc


def refresh_candidates(knowledge: Path, destination: Path) -> list[dict]:
    """Download to a review area; NEVER promote new web text to verified evidence."""
    sources = load_sources(knowledge / "sources.json")
    destination.mkdir(parents=True, exist_ok=True)
    report = []
    with OfficialDownloader() as downloader:
        for source in sources.values():
            if source.verification_status != "verified":
                continue
            try:
                body = downloader.fetch(source)
                (destination / f"{source.source_id}.{source.format}").write_bytes(body)
                if source.format == "html":
                    sections = extract_html(body, source)
                else:
                    old = load_sections(knowledge / "verified_sections.jsonl", sources)
                    pages = {s.page: s.section for s in old if s.source_id == source.source_id and s.page}
                    sections = extract_pdf(body, source, pages)
                write_jsonl(destination / f"{source.source_id}.candidates.jsonl", sections)
                report.append({"source_id": source.source_id, "status": "requires_review",
                               "sha256": digest(body), "sections": len(sections)})
            except RagError as exc:
                report.append({"source_id": source.source_id, "status": "failed", "error": str(exc)})
    atomic_text(destination / "report.json", json.dumps(report, indent=2) + "\n")
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--knowledge-dir", type=Path, default=KNOWLEDGE_DIR)
    parser.add_argument("--index-dir", type=Path, default=PROJECT_ROOT / "runtime/rag_index")
    parser.add_argument("--sections", type=Path, help="Locally supplied, verified Section JSONL")
    parser.add_argument("--passages-only", action="store_true")
    parser.add_argument("--refresh-candidates", action="store_true", help="Network collection for review; does not rebuild")
    parser.add_argument("--candidate-dir", type=Path, default=PROJECT_ROOT / "runtime/source-review")
    parser.add_argument("--device", choices=("cpu", "auto", "cuda"), default="auto")
    args = parser.parse_args(argv)
    try:
        if args.refresh_candidates:
            report = refresh_candidates(args.knowledge_dir, args.candidate_dir)
            print(json.dumps(report, indent=2))
            return int(any(r["status"] == "failed" for r in report))
        sources = load_sources(args.knowledge_dir / "sources.json")
        sections = load_sections(args.sections or args.knowledge_dir / "verified_sections.jsonl", sources)
        passages = chunk_sections(sections, sources)
        write_jsonl(args.knowledge_dir / "passages.jsonl", passages)
        print(f"Verified passages: {len(passages)} from {len({p.source_id for p in passages})} documents")
        if not args.passages_only:
            from .index import MiniLMEncoder, build_index
            encoder = MiniLMEncoder(device=args.device)
            built = build_index(args.knowledge_dir, args.index_dir, encoder)
            print(f"Index {'built' if built else 'reused'}: {args.index_dir}")
        return 0
    except (RagError, ValueError, OSError) as exc:
        print(f"RAG ingestion error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
