"""Conservative, optional surface normalization; no diagnosis or semantic rewriting."""
import re

_FILLER = re.compile(r'^(?:please\s+)?(?:can you help me understand\s+|help me understand\s+|could you tell me\s+)', re.I)


def normalize_query(query: str) -> str:
    # Never strip negations, symptoms, durations, drug names or qualifiers.
    compact = ' '.join(query.split())
    normalized = _FILLER.sub('', compact, count=1).strip()
    return normalized or compact
