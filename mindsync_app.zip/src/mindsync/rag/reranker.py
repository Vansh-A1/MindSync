"""Optional, pinned CPU CrossEncoder. Scores are logits, never probabilities."""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Protocol

import numpy as np

from .index import passage_input
from .ingest import PROJECT_ROOT
from .schemas import Passage, RagError

RERANK_MODEL = 'cross-encoder/ms-marco-MiniLM-L6-v2'
RERANK_REVISION = '233902d25c440f23af6f7d6e94d2946bac0bee0a'


class RerankError(RagError):
    pass


class Reranker(Protocol):
    def score(self, query: str, passages: list[Passage]) -> list[float]: ...


class CrossEncoderReranker:
    _models: dict[tuple, object] = {}
    _lock = threading.Lock()

    def __init__(self, *, model_name: str = RERANK_MODEL, device: str = 'cpu',
                 local_files_only: bool = True, cache_dir: Path | None = None,
                 batch_size: int = 16):
        if model_name != RERANK_MODEL:
            raise ValueError('Only the benchmarked, pinned reranker is supported')
        if device not in {'cpu', 'cuda'} or isinstance(batch_size, bool) or batch_size < 1:
            raise ValueError('Invalid reranker device/batch size')
        self.device, self.local_files_only = device, local_files_only
        self.cache_dir = cache_dir or PROJECT_ROOT / 'runtime/huggingface'
        self.batch_size = batch_size
        self.load_ms = 0.0
        self._load_failure: str | None = None

    @property
    def fingerprint(self):
        return {'name': RERANK_MODEL, 'revision': RERANK_REVISION,
                'pair_input': 'query-title-section-text-v1', 'activation': 'identity-logits',
                'long_passages': '512-token-pair-windows-overlap32-max-v1'}

    def load(self):
        if self._load_failure:
            raise RerankError(self._load_failure)
        os.environ.setdefault('HF_HOME', str(self.cache_dir))
        os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
        os.environ.setdefault('HF_HUB_DISABLE_IMPLICIT_TOKEN', '1')
        os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
        import torch
        from sentence_transformers import CrossEncoder
        key = (RERANK_MODEL, RERANK_REVISION, self.device, str(self.cache_dir.resolve()))
        with self._lock:
            if key not in self._models:
                start = time.perf_counter()
                try:
                    self._models[key] = CrossEncoder(
                        RERANK_MODEL, revision=RERANK_REVISION, device=self.device,
                        cache_folder=str(self.cache_dir / 'hub'), token=False,
                        trust_remote_code=False, local_files_only=self.local_files_only,
                        model_kwargs={'use_safetensors': True}, activation_fn=torch.nn.Identity(),
                        max_length=512)
                except Exception as exc:
                    self._load_failure = f'Pinned reranker unavailable: {type(exc).__name__}'
                    raise RerankError(self._load_failure) from exc
                finally:
                    self.load_ms = (time.perf_counter() - start) * 1000
            return self._models[key]

    def score(self, query: str, passages: list[Passage]) -> list[float]:
        if not passages:
            return []
        try:
            model = self.load()
            tokenizer = model.tokenizer
            query_tokens = tokenizer.encode(query, add_special_tokens=False, truncation=False, verbose=False)
            capacity = 512 - len(query_tokens) - tokenizer.num_special_tokens_to_add(pair=True)
            if capacity <= 32:
                raise RerankError('Query is too long to rerank without losing its qualifiers')
            pairs, owners = [], []
            for owner, passage in enumerate(passages):
                tokens = tokenizer.encode(passage_input(passage), add_special_tokens=False,
                                          truncation=False, verbose=False)
                for start in range(0, len(tokens), capacity - 32):
                    pairs.append((query, tokenizer.decode(tokens[start:start + capacity], skip_special_tokens=True)))
                    owners.append(owner)
                    if start + capacity >= len(tokens):
                        break
            raw = np.asarray(model.predict(pairs, batch_size=self.batch_size,
                                           show_progress_bar=False, convert_to_numpy=True)).reshape(-1)
            if len(raw) != len(pairs) or not np.isfinite(raw).all():
                raise RerankError('Reranker returned invalid scores')
            scores = np.full(len(passages), -np.inf)
            for owner, value in zip(owners, raw, strict=True):
                scores[owner] = max(scores[owner], float(value))
            if not np.isfinite(scores).all():
                raise RerankError('Reranker omitted a passage')
            return scores.tolist()
        except RerankError:
            raise
        except Exception as exc:
            raise RerankError(f'Local reranking failed: {type(exc).__name__}') from exc
