"""BM25, semantic and reciprocal-rank-fused retrieval with verified citations."""

from __future__ import annotations

import argparse
import json
import re
import sys
import math
import time
import warnings
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Literal

import numpy as np
from rank_bm25 import BM25Okapi

from .index import Encoder, LoadedIndex, MiniLMEncoder, load_index, passage_input
from .ingest import KNOWLEDGE_DIR, PROJECT_ROOT
from .schemas import EvidenceChunk, IndexError, Passage, RagError, SourceError, SourceRecord
from .sources import validate_passage
from .query_processing import normalize_query
from .reranker import Reranker, RerankError, CrossEncoderReranker, RERANK_MODEL

Method = Literal["bm25", "dense", "hybrid"]
STOP_WORDS = frozenset("a an and are as at be by can do for from how i in is it me my of on or that the this to was we what when with you your".split())


def tokenize(text: str) -> list[str]:
    return [token for token in re.findall(r"[^\W_]+", text.casefold(), flags=re.UNICODE)
            if token not in STOP_WORDS and len(token) > 1]


def validate_query(query: str, top_k: int) -> str:
    if not isinstance(query, str):
        raise ValueError("query must be a string")
    if len(query) > 4096:
        raise ValueError("query must be at most 4096 characters")
    if isinstance(top_k, bool) or not isinstance(top_k, int) or not 1 <= top_k <= 100:
        raise ValueError("top_k must be an integer between 1 and 100")
    return query.strip()


def reciprocal_rank_fusion(rankings: list[list[str]], constant: int = 60,
                           weights: list[float] | None = None) -> dict[str, float]:
    if isinstance(constant, bool) or not isinstance(constant, int) or constant < 1:
        raise ValueError("RRF constant must be a positive integer")
    scores: dict[str, float] = {}
    weights = [1.0] * len(rankings) if weights is None else weights
    if len(weights) != len(rankings) or any(not math.isfinite(w) or w < 0 for w in weights):
        raise ValueError("RRF needs one finite nonnegative weight per ranking")
    if weights and not any(weights):
        raise ValueError("At least one RRF weight must be positive")
    for ranking, weight in zip(rankings, weights, strict=True):
        if weight == 0:
            continue
        # A duplicate in one ranking must not receive multiple votes.
        for rank, chunk_id in enumerate(dict.fromkeys(ranking), start=1):
            scores[chunk_id] = scores.get(chunk_id, 0.0) + weight / (constant + rank)
    return scores


def validate_citation(evidence: EvidenceChunk, corpus: dict[str, Passage],
                      sources: dict[str, SourceRecord]) -> None:
    validate_passage(evidence, sources)
    stored = corpus.get(evidence.chunk_id)
    if stored is None:
        raise SourceError(f"Unknown evidence chunk {evidence.chunk_id}")
    for field in Passage.model_fields:
        if getattr(evidence, field) != getattr(stored, field):
            raise SourceError(f"Citation {evidence.chunk_id} differs from stored {field}")


@dataclass(frozen=True)
class RetrievalConfig:
    rrf_constant: int = 60
    dense_min_score: float = 0.32
    hybrid_candidate_min_score: float | None = 0.26
    dense_weight: float = 1.0
    lexical_weight: float = 1.0
    candidate_depth: int | None = None
    rerank_candidates: int = 20
    rerank_min_score: float | None = None
    rerank_failure: str = "fallback"
    normalize: bool = False

    def __post_init__(self):
        reciprocal_rank_fusion([], self.rrf_constant)
        reciprocal_rank_fusion([[], []], self.rrf_constant, [self.dense_weight, self.lexical_weight])
        if (not 0 <= self.dense_min_score <= 1 or
                self.hybrid_candidate_min_score is not None and
                not 0 <= self.hybrid_candidate_min_score <= self.dense_min_score):
            raise ValueError("Require 0 <= hybrid threshold <= dense threshold <= 1")
        for value in (self.candidate_depth, self.rerank_candidates):
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 100):
                raise ValueError("Candidate depths must be integers between 1 and 100")
        if self.rerank_candidates is None:
            raise ValueError("Reranker candidate count must be bounded")
        if self.rerank_min_score is not None and not math.isfinite(self.rerank_min_score):
            raise ValueError("Reranker threshold must be finite")
        if self.rerank_failure not in {"fallback", "raise"}:
            raise ValueError("Unknown reranker failure policy")


class GuidanceRetriever:
    def __init__(self, index: LoadedIndex, encoder: Encoder,
                 config: RetrievalConfig | None = None, reranker: Reranker | None = None):
        if index.manifest["encoder"] != encoder.fingerprint:
            raise IndexError("Query encoder is incompatible with the index")
        self.index = index
        self.encoder = encoder
        self.config = config or RetrievalConfig()
        self.reranker = reranker
        if self.config.rerank_min_score is not None and reranker is None:
            raise ValueError("Reranker score filtering requires a reranker")
        self.passages = {p.chunk_id: p for p in index.passages}
        documents = [tokenize(passage_input(p)) for p in index.passages]
        if not any(documents):
            raise IndexError("Corpus contains no searchable tokens")
        self.bm25 = BM25Okapi(documents)

    def search(self, query: str, top_k: int = 4, *, method: Method = "hybrid") -> list[EvidenceChunk]:
        return self.search_with_trace(query, top_k, method=method)[0]

    def search_with_trace(self, query: str, top_k: int = 4, *, method: Method = "hybrid") -> tuple[list[EvidenceChunk], dict]:
        """Diagnostic interface; the public search return type remains unchanged."""
        query = validate_query(query, top_k)
        original_query = query
        query = normalize_query(query) if self.config.normalize else query
        trace = {"candidate_ids": [], "rerank_ms": 0.0, "fallback": None,
                 "max_dense_score": None, "rerank_scores": {}, "retrieval_query": query}
        if method not in {"dense", "bm25", "hybrid"}:
            raise ValueError("method must be bm25, dense or hybrid")
        if not query or not tokenize(query):
            return [], trace
        self.index.assert_current()
        ids = [p.chunk_id for p in self.index.passages]
        lexical = self.bm25.get_scores(tokenize(query)) if method != "dense" else None
        dense = None
        if method != "bm25":
            encode_queries = getattr(self.encoder, "encode_queries", self.encoder.encode)
            vector = np.asarray(encode_queries([query]), dtype=np.float32)
            norm = float(np.linalg.norm(vector))
            if (vector.shape != (1, self.index.vectors.shape[1])
                    or not np.isfinite(vector).all() or not np.isfinite(norm) or norm == 0):
                raise IndexError("Invalid query embedding dimensions/values")
            dense = self.index.vectors @ (vector[0] / norm)
            trace["max_dense_score"] = float(dense.max())
            if float(dense.max()) < self.config.dense_min_score:
                return [], trace

        def ranked(scores: np.ndarray, eligible) -> list[str]:
            return [ids[i] for i in sorted(range(len(ids)), key=lambda i: (-float(scores[i]), ids[i]))
                    if eligible(i)]

        if method == "bm25":
            ordered = ranked(lexical, lambda i: lexical[i] > 0)
            scores = dict(zip(ids, map(float, lexical), strict=True))
        elif method == "dense":
            ordered = ranked(dense, lambda i: dense[i] >= self.config.dense_min_score)
            scores = dict(zip(ids, map(float, dense), strict=True))
        else:
            eligible = lambda i: (self.config.hybrid_candidate_min_score is None or
                                  dense[i] >= self.config.hybrid_candidate_min_score)
            semantic_ranks = ranked(dense, eligible)
            lexical_ranks = ranked(lexical, lambda i: eligible(i) and lexical[i] > 0)
            depth = self.config.candidate_depth
            semantic_ranks, lexical_ranks = semantic_ranks[:depth], lexical_ranks[:depth]
            scores = reciprocal_rank_fusion([semantic_ranks, lexical_ranks], self.config.rrf_constant,
                                            [self.config.dense_weight, self.config.lexical_weight])
            ordered = sorted(scores, key=lambda key: (-scores[key], key))
        # Candidate IDs are unique before reranking; preserve per-source provenance.
        ordered = list(dict.fromkeys(ordered))
        if self.reranker is not None:
            ordered = ordered[:self.config.rerank_candidates]
        trace["candidate_ids"] = list(ordered)
        if self.reranker is not None and ordered:
            start = time.perf_counter()
            try:
                values = self.reranker.score(original_query, [self.passages[key] for key in ordered])
                if len(values) != len(ordered) or not all(math.isfinite(v) for v in values):
                    raise RerankError("Reranker returned invalid scores")
                scores = dict(zip(ordered, values, strict=True))
                trace["rerank_scores"] = scores
                ordered.sort(key=lambda key: (-scores[key], key))
                if self.config.rerank_min_score is not None:
                    ordered = [key for key in ordered if scores[key] >= self.config.rerank_min_score]
            except RerankError as exc:
                if self.config.rerank_failure == "raise":
                    raise
                warnings.warn(f"{exc}; using the original hybrid retriever", RuntimeWarning, stacklevel=2)
                hits, fallback_trace = GuidanceRetriever(self.index, self.encoder).search_with_trace(
                    original_query, top_k, method=method)
                fallback_trace["fallback"] = str(exc)
                fallback_trace["rerank_ms"] = (time.perf_counter() - start) * 1000
                return hits, fallback_trace
            finally:
                trace["rerank_ms"] = (time.perf_counter() - start) * 1000
        offsets = {chunk_id: i for i, chunk_id in enumerate(ids)}
        results, seen_text = [], set()
        for chunk_id in ordered:
            passage = self.passages[chunk_id]
            if passage.content_hash in seen_text:
                continue
            seen_text.add(passage.content_hash)
            i = offsets[chunk_id]
            evidence = EvidenceChunk(**passage.model_dump(), score=scores[chunk_id], method=method,
                                     dense_score=float(dense[i]) if dense is not None else None,
                                     bm25_score=float(lexical[i]) if lexical is not None else None)
            validate_citation(evidence, self.passages, self.index.sources)
            results.append(evidence)
            if len(results) == top_k:
                break
        return results, trace


@lru_cache(maxsize=4)
def get_retriever(knowledge_dir: Path = KNOWLEDGE_DIR,
                  index_dir: Path = PROJECT_ROOT / "runtime/rag_index",
                  device: str = "auto") -> GuidanceRetriever:
    encoder = MiniLMEncoder(device=device, local_files_only=True)
    enabled = os.environ.get("RAG_RERANK_ENABLED", "false").lower()
    if enabled not in {"true", "false"}:
        raise ValueError("RAG_RERANK_ENABLED must be true or false")
    if enabled == "true":
        config = advanced_config()
        index = load_index(knowledge_dir, index_dir, encoder)
        if index.manifest["corpus"]["passages_sha256"] != "32931c92f353531d0730fae726f0c15c3b7f5eeae20239ffc44b4411618cb385":
            raise ValueError("Advanced environment profile needs recalibration for this corpus; "
                             "use an explicit GuidanceRetriever configuration")
        reranker = CrossEncoderReranker(model_name=os.environ.get("RAG_RERANK_MODEL", RERANK_MODEL),
                                       device="cuda" if device == "cuda" else "cpu")
        return GuidanceRetriever(index, encoder, config, reranker)
    return GuidanceRetriever(load_index(knowledge_dir, index_dir, encoder), encoder)


def advanced_config() -> RetrievalConfig:
    """Frozen dev selection; raw-logit cutoff is specific to this model/corpus.

    Defaults correspond to evaluation/optimization/selection.json. Environment
    overrides are experimental and require recalibration, especially candidate depth.
    """
    return RetrievalConfig(dense_min_score=0.0, hybrid_candidate_min_score=None,
                           dense_weight=0.6, lexical_weight=0.4, candidate_depth=20,
                           rerank_candidates=int(os.environ.get("RAG_RERANK_CANDIDATES", "20")),
                           rerank_min_score=float(os.environ.get("RAG_RERANK_MIN_SCORE", "-9.0")))


def search_guidance(query: str, top_k: int = 4) -> list[EvidenceChunk]:
    """Retrieve verified guidance. Empty/unrelated queries return []; index errors raise.

    Reuses the process-local retriever/model. After an intentional rebuild, call
    ``get_retriever.cache_clear()`` or restart the process. No network during search.
    Set RAG_RERANK_ENABLED=true for the evaluated advanced profile. False (default)
    preserves the original lightweight retriever. Returned score is a raw reranker
    logit when enabled, otherwise the original RRF score; neither is a probability.
    """
    query = validate_query(query, top_k)
    if not query or not tokenize(query):
        return []
    return get_retriever().search(query, top_k)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", required=True)
    parser.add_argument("--top-k", type=int, default=4)
    parser.add_argument("--method", choices=("bm25", "dense", "hybrid"), default="hybrid")
    parser.add_argument("--knowledge-dir", type=Path, default=KNOWLEDGE_DIR)
    parser.add_argument("--index-dir", type=Path, default=PROJECT_ROOT / "runtime/rag_index")
    parser.add_argument("--device", choices=("cpu", "auto", "cuda"), default="auto")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        query = validate_query(args.query, args.top_k)
        results = (get_retriever(args.knowledge_dir, args.index_dir, args.device).search(
            query, args.top_k, method=args.method) if query and tokenize(query) else [])
        if args.json:
            print(json.dumps({"query": query, "evidence": [r.model_dump(mode="json") for r in results]},
                             indent=2, ensure_ascii=False))
        else:
            print(f"Query: {query}\nMethod: {args.method}")
            if not results:
                print("No relevant verified evidence found.")
            for rank, result in enumerate(results, 1):
                page = f" | PDF page {result.page}" if result.page else ""
                print(f"\n{rank}. Score {result.score:.6f} | {result.chunk_id}\n"
                      f"{result.publisher} — {result.title}\n{result.section}{page}\n"
                      f"{result.url}\n{result.text[:500]}{'…' if len(result.text) > 500 else ''}")
        return 0
    except (RagError, ValueError, OSError) as exc:
        print(f"RAG search error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
