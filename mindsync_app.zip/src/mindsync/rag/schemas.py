"""Internal retrieval models; shared application contracts belong to Developer 1."""

from __future__ import annotations

import hashlib
import re
import unicodedata
from datetime import date
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

OFFICIAL_HOSTS = frozenset({"www.who.int", "iris.who.int", "www.nhs.uk", "www.nimh.nih.gov"})


class RagError(RuntimeError):
    """An actionable ingestion, configuration or index error."""


class SourceError(RagError):
    pass


class IndexError(RagError):
    pass


class StaleIndexError(IndexError):
    pass


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", text)).strip()


def digest(text: str | bytes) -> str:
    return hashlib.sha256(text.encode("utf-8") if isinstance(text, str) else text).hexdigest()


def trusted_url(value: str) -> str:
    url = urlsplit(value)
    if (url.scheme != "https" or url.hostname not in OFFICIAL_HOSTS
            or url.username or url.password or url.port not in (None, 443)
            or url.fragment):
        raise ValueError("Expected an HTTPS URL on an explicitly approved official host")
    return value


class FrozenModel(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class SourceRecord(FrozenModel):
    source_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]+$")
    publisher: str = Field(min_length=1)
    title: str = Field(min_length=1)
    url: str
    format: Literal["html", "pdf"]
    topics: tuple[str, ...] = Field(min_length=1)
    verification_status: Literal["verified", "excluded", "unavailable", "pending"]
    last_checked: date
    licence_notes: str = Field(min_length=1)
    licence_url: str
    selection_notes: str = ""
    content_selector: str = "main"
    section_allowlist: tuple[str, ...] = ()
    download_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    download_url: str | None = None

    _url = field_validator("url", "licence_url")(trusted_url)

    @field_validator("download_url")
    @classmethod
    def validate_download(cls, value: str | None) -> str | None:
        return trusted_url(value) if value else None


class Section(FrozenModel):
    source_id: str
    section: str = Field(min_length=1)
    blocks: tuple[str, ...] = Field(min_length=1)
    page: int | None = Field(default=None, ge=1)
    document_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @field_validator("blocks")
    @classmethod
    def normalize_blocks(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        blocks = tuple(clean_text(block) for block in value if clean_text(block))
        if not blocks:
            raise ValueError("A section must contain text")
        return blocks


def make_chunk_id(source_id: str, section: str, page: int | None, text: str) -> str:
    identity = f"{source_id}\n{section}\n{page}\n{text}"
    return f"{source_id}:{digest(identity)[:20]}"


class Passage(FrozenModel):
    chunk_id: str
    source_id: str
    publisher: str = Field(min_length=1)
    title: str = Field(min_length=1)
    section: str = Field(min_length=1)
    url: str
    text: str = Field(min_length=1)
    page: int | None = Field(default=None, ge=1)
    topics: tuple[str, ...] = Field(min_length=1)
    content_hash: str = Field(pattern=r"^[0-9a-f]{64}$")

    _url = field_validator("url")(trusted_url)

    @model_validator(mode="after")
    def check_identity(self) -> Passage:
        if self.text != clean_text(self.text):
            raise ValueError("Passage text must use canonical whitespace")
        if self.content_hash != digest(self.text):
            raise ValueError("Passage content hash does not match text")
        if self.chunk_id != make_chunk_id(self.source_id, self.section, self.page, self.text):
            raise ValueError("Chunk ID does not match source, section, page and text")
        return self


class EvidenceChunk(Passage):
    """A scored passage, not a replacement for the future shared SourceRef model."""

    score: float = Field(allow_inf_nan=False)
    method: Literal["bm25", "dense", "hybrid"]
    dense_score: float | None = Field(default=None, allow_inf_nan=False)
    bm25_score: float | None = Field(default=None, allow_inf_nan=False)
