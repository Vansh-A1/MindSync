"""Explicit source registry and bounded, robots-aware official-source downloads."""

from __future__ import annotations

import json
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser

import httpx
from pydantic import ValidationError

from .schemas import Passage, SourceError, SourceRecord, trusted_url

USER_AGENT = "MindSyncResearch/0.1 (+https://github.com/Vansh-A1/MindSync)"


def load_sources(path: Path) -> dict[str, SourceRecord]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, list) or not raw:
            raise ValueError("Source registry must be a nonempty JSON list")
        records = [SourceRecord.model_validate(item) for item in raw]
        result = {item.source_id: item for item in records}
        if len(result) != len(records) or len({r.url for r in records}) != len(records):
            raise ValueError("Duplicate source ID or canonical URL")
        return result
    except (OSError, ValueError, ValidationError) as exc:
        raise SourceError(f"Invalid source registry {path}: {exc}") from exc


def validate_passage(passage: Passage, sources: dict[str, SourceRecord]) -> None:
    source = sources.get(passage.source_id)
    if source is None or source.verification_status != "verified":
        raise SourceError(f"Unverified or missing source: {passage.source_id}")
    for field in ("publisher", "title", "url", "topics"):
        if getattr(passage, field) != getattr(source, field):
            raise SourceError(f"Passage {passage.chunk_id} has mismatched {field}")
    if source.format == "pdf" and passage.page is None:
        raise SourceError(f"PDF passage {passage.chunk_id} is missing a page")


class OfficialDownloader:
    """No general web crawler: fetch only a registered source after robots checks.

    All redirects are checked before following. Network failures fail closed;
    robots 404 alone means there is no policy. One request/second per host is
    the minimum, increased by robots crawl-delay/request-rate when specified.
    """

    def __init__(self, client: httpx.Client | None = None, min_interval: float = 1.0):
        self.client = client or httpx.Client(timeout=30, follow_redirects=False)
        self._owns_client = client is None
        self.min_interval = min_interval
        self._last: dict[str, float] = {}
        self._robots: dict[str, RobotFileParser | None] = {}

    def __enter__(self) -> OfficialDownloader:
        return self

    def __exit__(self, *args: object) -> None:
        if self._owns_client:
            self.client.close()

    def _request(self, url: str, limit: int, interval: float) -> tuple[int, bytes, str, str]:
        trusted_url(url)
        host = urlsplit(url).netloc
        time.sleep(max(0, self._last.get(host, 0) + interval - time.monotonic()))
        try:
            with self.client.stream("GET", url, headers={"User-Agent": USER_AGENT},
                                    follow_redirects=False) as response:
                self._last[host] = time.monotonic()
                parts, size = [], 0
                for part in response.iter_bytes():
                    size += len(part)
                    if size > limit:
                        raise SourceError(f"Download exceeds {limit} bytes: {url}")
                    parts.append(part)
                return (response.status_code, b"".join(parts),
                        response.headers.get("location", ""),
                        response.headers.get("content-type", ""))
        except httpx.HTTPError as exc:
            raise SourceError(f"Download failed for {url}: {type(exc).__name__}") from exc

    def _policy(self, url: str) -> RobotFileParser | None:
        parts = urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin not in self._robots:
            status, body, _, _ = self._request(origin + "/robots.txt", 512_000, self.min_interval)
            if status == 404:
                self._robots[origin] = None
            elif status == 200:
                if body.lstrip().lower().startswith((b"<!doctype html", b"<html")):
                    raise SourceError(f"Expected robots.txt, received HTML for {origin}")
                parser = RobotFileParser()
                parser.parse(body.decode("utf-8", errors="replace").splitlines())
                self._robots[origin] = parser
            else:
                raise SourceError(f"Cannot verify robots policy ({status}) for {origin}")
        return self._robots[origin]

    def fetch(self, source: SourceRecord) -> bytes:
        url = source.download_url or source.url
        for _ in range(5):
            try:
                trusted_url(url)
            except ValueError as exc:
                raise SourceError(f"Redirect outside approved sources: {url}") from exc
            policy = self._policy(url)
            interval = self.min_interval
            if policy is not None:
                if not policy.can_fetch(USER_AGENT, url):
                    raise SourceError(f"Robots policy disallows {url}")
                interval = max(interval, policy.crawl_delay(USER_AGENT) or 0)
                rate = policy.request_rate(USER_AGENT)
                if rate:
                    interval = max(interval, rate.seconds / rate.requests)
            status, body, location, content_type = self._request(url, 25_000_000, interval)
            if status in (301, 302, 303, 307, 308) and location:
                url = urljoin(url, location)
                continue
            if status != 200:
                raise SourceError(f"Source returned HTTP {status}: {url}")
            if source.format == "pdf" and not body.startswith(b"%PDF"):
                raise SourceError(f"Expected PDF content: {url}")
            if source.format == "html" and "text/html" not in content_type:
                raise SourceError(f"Expected HTML content: {url}")
            if not body.strip():
                raise SourceError(f"Empty document: {url}")
            return body
        raise SourceError(f"Too many redirects for {source.source_id}")
